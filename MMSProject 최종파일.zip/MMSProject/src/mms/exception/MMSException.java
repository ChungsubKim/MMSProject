package mms.exception;

public class MMSException extends Exception {
	public MMSException(String message){
		super(message);
	}
}