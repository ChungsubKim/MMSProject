//LoginView

package mms.view;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import mms.controller.PatientController;
import mms.model.dto.Patient;


public class LoginView extends JFrame implements ActionListener{
   private JTextField idTF;
   private JPasswordField pwdTF;
   private JLabel idLabel, pwdLabel, imageLabel;
   private JButton loginBtn, joinBtn, findBtn, confirmBtn;
   private ImageIcon originLogo, logo, loginImageBtn, joinImageBtn, findImageBtn, confirmImageBtn ;
   private JPanel panel;
   private TableModel dataModel;
   
   
   private Image image, changeImage, icon;
   
   
   private PatientController pCon = new PatientController();
   
   
   
   public LoginView() {
      this.setTitle("로그인");
      this.setBounds(100, 100, 350, 500);
      this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
      
      Toolkit tk = Toolkit.getDefaultToolkit();
      icon = tk.getImage("image/mms_icon.png");
      this.setIconImage(icon);
      
      panel = new JPanel();
      panel.setBackground(Color.white);
      panel.setLayout(null);
      
      
      originLogo = new ImageIcon("image/mms_logo.png");
      image = originLogo.getImage(); //ImageIcon에서 image추출
      changeImage = image.getScaledInstance(300, 100, Image.SCALE_SMOOTH); // image 크기 조절해 새로운 객체생성
      logo = new ImageIcon(changeImage); // 다시 ImageIcon 객체 생성
      
      imageLabel = new JLabel(logo);
      imageLabel.setBounds(20, 70, 300, 100);
      panel.add(imageLabel);
   
      idLabel = new JLabel(" 아이디 ");
      idLabel.setBounds(40, 200, 100, 30);
      pwdLabel = new JLabel("비밀번호");
      pwdLabel.setBounds(40, 250, 100, 30);
      panel.add(idLabel);
      panel.add(pwdLabel);
      
      /*checkLabel = new JLabel("아이디와 비밀번호를 확인해주세요");
      checkLabel.setBounds(70, 290, 300, 30);
      checkLabel.setForeground(Color.RED);*/
      
      idTF = new JTextField(20);
      idTF.setBounds(130, 200, 170, 30);
      pwdTF = new JPasswordField(20);
      pwdTF.setBounds(130, 250, 170, 30);
      panel.add(idTF);
      panel.add(pwdTF);
      
      loginImageBtn = new ImageIcon("image/login.jpg");
      joinImageBtn = new ImageIcon("image/join.jpg");
      loginBtn = new JButton(loginImageBtn);
      loginBtn.setBounds(80, 330, 80, 40);
      joinBtn = new JButton(joinImageBtn);
      joinBtn.setBounds(188, 330, 80, 40);
      panel.add(loginBtn);
      panel.add(joinBtn);
      
      findImageBtn = new ImageIcon("image/find_idpw.jpg");
      findBtn = new JButton(findImageBtn);
      findBtn.setBounds(80, 380, 188, 40);
      panel.add(findBtn);
      
      pwdTF.addActionListener(this);
      loginBtn.addActionListener(this);
      joinBtn.addActionListener(this);
      findBtn.addActionListener(this);
     
      
      this.add(panel);      

      this.setResizable(false);
      this.setVisible(true);
   }

   
   @Override
   public void actionPerformed(ActionEvent event) {
      if(event.getSource()== loginBtn || event.getSource() == pwdTF){

         if(pCon.loginPatient(idTF.getText(), String.valueOf(pwdTF.getPassword())) == 1){
            if(idTF.getText().equals("mms")){
               new DoctorView().setVisible(true); //관리자
               //new DChatView().setVisible(true);		////////////////////확인용으로 일단 꺼놈
            }else
               new PatientView(idTF.getText()).setVisible(true); //일반회원
            this.setVisible(false);            
            }         
      }
      
      else if(event.getSource() == joinBtn){
         new JoinFrame().setVisible(true);
      }
      else if(event.getSource() == findBtn){
         new FindFrame().setVisible(true);
      }     
   }
   
   
   //회원가입 내부클래스
   private class JoinFrame extends JFrame implements ActionListener{
      private JTextField idTF, nameTF, pidTF, phoneTF, addressTF, emailTF;
      private JPasswordField pwd1TF, pwd2TF;
      private JLabel idLabel, pwd1Label, pwd2Label, nameLabel, pidLabel, phoneLabel, addressLabel,
                  pidExLabel, phoneExLabel, emailLabel, textLabel;
      private JButton checkIDBtn, joinBtn, cancelBtn;
      private ImageIcon checkIDImageBtn, joinImageBtn, cancelImageBtn;
      private JPanel panel;
      private JTable listTable;
     

      
      public JoinFrame(){
         this.setTitle("회원 가입");
         this.setBounds(200, 200, 420, 500);
         this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);

         Toolkit tk = Toolkit.getDefaultToolkit();
         icon = tk.getImage("image/mms_icon.png");
         this.setIconImage(icon);
         
         panel = new JPanel();
         panel.setBackground(Color.white);
         panel.setLayout(null);
         
         idLabel = new JLabel  ("아이디(*)");
         idLabel.setBounds(20, 20, 100, 30);
         pwd1Label = new JLabel("비밀번호(*)");
         pwd1Label.setBounds(20, 60, 100, 30);
         pwd2Label = new JLabel("비밀번호 확인(*)");
         pwd2Label.setBounds(20, 100, 100, 30);
         nameLabel = new JLabel("이름(*)");
         nameLabel.setBounds(20, 140, 100, 30);
         pidLabel = new JLabel("주민번호(*)");
         pidLabel.setBounds(20, 180, 100, 30);
         addressLabel = new JLabel("주소(*)");
         addressLabel.setBounds(20, 260, 100, 30);
         phoneLabel = new JLabel("전화번호(*)");
         phoneLabel.setBounds(20, 220, 100, 30);
         emailLabel = new JLabel("email");
         emailLabel.setBounds(20, 300, 100, 30);
         
         pidExLabel = new JLabel("예) 000000-0000000");
         pidExLabel.setBounds(260, 180, 120, 30);
         phoneExLabel = new JLabel("예) 000-0000-0000");
         phoneExLabel.setBounds(260, 220, 120, 30);
         textLabel = new JLabel("(*)은 필수 입력 사항입니다.");
         textLabel.setBounds(250, 330, 300, 30);
               
         panel.add(idLabel);
         panel.add(pwd1Label);
         panel.add(pwd2Label);
         panel.add(nameLabel);
         panel.add(pidLabel);
         panel.add(phoneLabel);
         panel.add(addressLabel);
         panel.add(pidExLabel);
         panel.add(phoneExLabel);
         panel.add(emailLabel);
         panel.add(textLabel);
         
         idTF = new JTextField(20);
         idTF.setBounds(130, 20, 100, 30);
         pwd1TF = new JPasswordField(30);
         pwd1TF.setBounds(130, 60, 100, 30);
         pwd2TF = new JPasswordField(30);
         pwd2TF.setBounds(130, 100, 100, 30);
         nameTF = new JTextField(20);
         nameTF.setBounds(130, 140, 100, 30);
         pidTF = new JTextField(25);
         pidTF.setBounds(130, 180, 120, 30);
         phoneTF = new JTextField(25);
         phoneTF.setBounds(130, 220, 120, 30);
         addressTF = new JTextField(40);
         addressTF.setBounds(130, 260, 200, 30);
         emailTF = new JTextField(40);
         emailTF.setBounds(130, 300, 200, 30);
         
         panel.add(idTF);
         panel.add(pwd1TF);
         panel.add(pwd2TF);
         panel.add(nameTF);
         panel.add(pidTF);
         panel.add(phoneTF);
         panel.add(addressTF);
         panel.add(emailTF);
               
         checkIDImageBtn = new ImageIcon("image/checkID.jpg");
         checkIDBtn = new JButton(checkIDImageBtn);
         checkIDBtn.setBounds(240, 20, 100, 30);
      
         joinImageBtn = new ImageIcon("image/join.jpg");
         joinBtn = new JButton(joinImageBtn);
         joinBtn.setBounds(90, 400, 80, 30);   
         
         cancelImageBtn = new ImageIcon("image/cancel.jpg");
         cancelBtn = new JButton(cancelImageBtn);
         cancelBtn.setBounds(240, 400, 80, 30);   
         
         panel.add(checkIDBtn);
         panel.add(joinBtn);
         panel.add(cancelBtn);
         
         checkIDBtn.addActionListener(this);
         joinBtn.addActionListener(this);
         cancelBtn.addActionListener(this);
         
         this.add(panel);
         
         this.setResizable(false);
         this.setVisible(true);
      }

      @Override
      public void actionPerformed(ActionEvent event) {
         
    	  if(event.getSource() == checkIDBtn){ //아이디 중복 검사
              boolean check = false;
              for(char word : idTF.getText().toCharArray()) {
                   if( !((word >='a' && word <='z')||(word>='0' && word<='9')) )
                      check = true;
               }            
              if(idTF.getText().isEmpty()){
                 JOptionPane.showMessageDialog(null, "아이디를 입력해주세요", "알림", JOptionPane.DEFAULT_OPTION);
              }
              else if (idTF.getText().length() < 4){
                 JOptionPane.showMessageDialog(null, "아이디를 4글자 이상 입력해주세요", "알림", JOptionPane.DEFAULT_OPTION);
              }
              else if(check){
                 JOptionPane.showMessageDialog(null, "영어 소문자, 숫자만 입력해주세요", "알림", JOptionPane.DEFAULT_OPTION);
              }
              else{
                Object[] list = pCon.selectList().toArray();
                Patient comp = null;
                String id = idTF.getText();
                int index = -1;
                for(int i = 0; i < list.length; i++){
                   comp = (Patient)list[i];
                   if(comp.getPatId().equals(id)){
                      index = i;
                      break;
                   }
                }
                
                if(index > -1)
                   JOptionPane.showMessageDialog(null, "이미 존재하는 아이디입니다.", "알림", JOptionPane.DEFAULT_OPTION);
                else
                   JOptionPane.showMessageDialog(null, "사용 가능한 아이디입니다.", "알림", JOptionPane.DEFAULT_OPTION);
              }
             }
  
         else if(event.getSource() == joinBtn){
            String originPwd = new String(pwd1TF.getPassword());
             String confirmPwd = new String(pwd2TF.getPassword());
             String name = nameTF.getText();
             String ssn = pidTF.getText();
             String phone = phoneTF.getText();
             boolean check1 = false, check2 = false, check3 = false, check4 = false;
             

             
             
             //pw 확인
             if (originPwd.equals(confirmPwd)) {
            	 //이름 한글
            	 if(name != null) {
            		 for(char word : name.toCharArray()) {
            			 if(!(word >= '가' && word <= '힣'))
            				 check1 = true;       
            			 }//for close
	            	 if(check1)
	            		 JOptionPane.showMessageDialog(null, "이름을 한글로 작성해주세요.");
	            	 else{	            		 
	            		 //주민번호
	                	 if(ssn != null) {
	     		        for(char word : ssn.toCharArray()) {
	     		          if(!(word == '-' || word == '0' || word == '1' || word == '2' || word == '3' || word == '4' 
	     		                   || word == '5'|| word == '6' || word == '7' || word == '8' || word == '9')){
	     		                check2 = true;
	     		                    }
	     		                 }//for close
	     		        if(check2)
	     		        	JOptionPane.showMessageDialog(null, "주민등록번호를 다시 입력해주세요.");
	     		        else{

	     		        	
	     		        	if(phone != null){
		     		        	char[] word = phone.toCharArray();
		                         String first = "";
		        			                 for(int i = 0; i < word.length; i++) {
		        			                    if(i < 3)
		        			                       first += word[i];
		        			                    if(i == 3 && !first.equals("010"))
		        			                       check3 = true;
		        			                    if(!(word[i] == '-' || word[i] == '0' || word[i] == '1' || word[i] == '2' || word[i] == '3' || word[i] == '4' || word[i] == '5'
		        			                          || word[i] == '6' || word[i] == '7' || word[i] == '8' || word[i] == '9'))
		        			                       check4 = true;
		        			                 }//for close
		        			                 if(check3 || check4)
		        			                	 JOptionPane.showMessageDialog(null, "전화번호를 다시 입력해주세요.");
		        			                 else{
		        			                	 Patient patient = new Patient();
		        			                	    
		        			                	    patient.setPatNo(patient.getPatNo());
		        			                	    patient.setPatId(idTF.getText());
		        			                	    patient.setPatPw(new String(pwd1TF.getPassword()));
		        			                	    patient.setPatName(nameTF.getText());
		        			                	    patient.setPatPhone(phoneTF.getText());
		        			                	    patient.setPatSsn(pidTF.getText());
		        			                	    patient.setPatEmail(emailTF.getText());
		        			                	    patient.setPatAddress(addressTF.getText());
		        			                	    
		        			                	    if(pCon.insertPatient(patient) > 0){
			        			                	       listTable = new JTable();
			        			                	       listTable.setModel(displayList());
			        			                	       //JOptionPane.showMessageDialog(null, "회원 가입이 완료되었습니다.");
			        			                	}//if close
		        			                 }
	     		        			}
	     		        		}
	                	   }
	            	 	}
		                
		            }
                              
             }else
                JOptionPane.showMessageDialog(null, "비밀번호가 다릅니다.");
            }
           
         else if(event.getSource() == cancelBtn){
            this.setVisible(false);
         }
         
      }
      
   }
   
   
//  아이디/비번찾기 내부클래스
  private class FindFrame extends JFrame implements ActionListener{
     private JLabel label1, label2, pidExLabel;
     private JTextField tf1, tf2;
     private JPanel panel;
     
     public FindFrame(){
        this.setTitle("아이디 비밀번호 찾기");
        this.setBounds(200, 200, 420, 400);
        this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        
        Toolkit tk = Toolkit.getDefaultToolkit();
        icon = tk.getImage("image/mms_icon.png");
        this.setIconImage(icon);

        panel = new JPanel();
        panel.setBackground(Color.white);
        panel.setLayout(null);
        
        label1 = new JLabel("이름");
        label1.setBounds(20, 60, 100, 30);
        label2 = new JLabel("주민번호");
        label2.setBounds(20, 100, 100, 30);      
        panel.add(label1);
        panel.add(label2);
        
        tf1 = new JTextField(30);
        tf1.setBounds(130, 60, 100, 30);
        tf2 = new JTextField(30);
        tf2.setBounds(130, 100, 110, 30);   
        panel.add(tf1);
        panel.add(tf2);
        
        
        confirmImageBtn = new ImageIcon("image/confirm.png");
        confirmBtn = new JButton(confirmImageBtn);
        confirmBtn.setBounds(260, 300, 100,30);
        panel.add(confirmBtn);
        
        pidExLabel = new JLabel("예) 000000-0000000");
        pidExLabel.setBounds(260, 100, 120, 30);      
        panel.add(pidExLabel);
        
        this.add(panel);
        
        confirmBtn.addActionListener(this);
        
        this.setResizable(false);
        this.setVisible(true);
     }

     @Override
     public void actionPerformed(ActionEvent event) {
        if(event.getSource() == confirmBtn) {
           Object[] list = pCon.selectList().toArray();
           Patient comp = null;
           int index = -1;
           String name = tf1.getText();
           String ssn = tf2.getText();
           for(int i = 0; i < list.length; i++) {
              comp = (Patient)list[i];
              if(comp.getPatName().equals(tf1.getText())) {
                 if(comp.getPatSsn().equals(tf2.getText())) {
                    index = i; 
                    break;
                 }
              }
           }
           if(index > -1)
              JOptionPane.showConfirmDialog(null, "id : " + comp.getPatId() + ", pw : " + comp.getPatPw(), "ID/PW 찾기",
                    JOptionPane.DEFAULT_OPTION);
           else if(name.equals("관리자") && ssn.equals("800914-1722006"))
              JOptionPane.showMessageDialog(null, "id : mms \npw : mms");
           else if(name.length() == 0 || ssn.length() == 0)
              JOptionPane.showMessageDialog(null, "모든 값을 입력해주세요");
           else
              JOptionPane.showConfirmDialog(null, "검색 결과가 없습니다.", "ID/PW 찾기", JOptionPane.DEFAULT_OPTION);   
        }
     }      
  }
      
   


   private TableModel displayList() {
      //제목행 정의
            String[] columnNames = {"pat_no", "pat_id", "pat_pw", "pat_name", "pat_phone", "pat_ssn", "pat_email", "pat_address"};
            
            //데이터 행은 2차원배열로 선언함
            Object[][] data = null;
            ArrayList<Patient> list = pCon.selectList();
            data = new Object[list.size()][];
            //2차원배열 객체에 값 저장하기
            for(int i = 0; i < list.size(); i++){
               data[i] = new Object[8];
               Patient patient = list.get(i);
               
               data[i][0] = patient.getPatNo();
               data[i][1] = patient.getPatId();
               data[i][2] = patient.getPatPw();
               data[i][3] = patient.getPatName();
               data[i][4] = patient.getPatPhone();
               data[i][5] = patient.getPatSsn();
               data[i][6] = patient.getPatEmail();
               data[i][7] = patient.getPatAddress();
            }
            
            dataModel =  new DefaultTableModel(data, columnNames);
            return dataModel;
   }

}