package mms.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import mms.controller.PatientController;
import mms.model.dto.Patient;

public class PSearchView extends JFrame implements ActionListener{
   
   private TableModel dataModel;
   private JTable listTable;
   private JTextField patientNameText, patientNoText, patientSsnText, patientPhoneText;
   private JButton backBtn;
   private Image icon;
   
   public PSearchView(){
      
      this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
      this.setTitle(" MMS 환자검색");
      this.setBounds(100, 100, 1100, 700);
      
      Toolkit tk = Toolkit.getDefaultToolkit();
      icon = tk.getImage("image/mms_icon.png");
      this.setIconImage(icon);
      
      
      JPanel totalPane = new JPanel();
      totalPane.setLayout(null);
      
      JPanel northPane = new JPanel();
      northPane.setBackground(Color.WHITE);
      northPane.setBounds(0, 0, 1100, 200);
      northPane.setLayout(null);
      
      JPanel titlePane = new JPanel();
      JLabel titleLabel = new JLabel("환자 검색");
      titleLabel.setFont(new Font("돋음", Font.BOLD, 40));
      titlePane.add(titleLabel);
      titlePane.setBounds(0, 20, 250, 100);
      titlePane.setBackground(Color.WHITE);
      northPane.add(titlePane);
      
      JLabel patientNameLabel = new JLabel("환자명 : ");
      patientNameLabel.setFont(new Font("돋음", Font.BOLD, 20));
      patientNameLabel.setBounds(10, 113, 100, 80);
      patientNameText = new JTextField();
      patientNameText.setBounds(100, 140, 80, 30);
      northPane.add(patientNameLabel);
      northPane.add(patientNameText);
      
      JLabel patientNoLabel = new JLabel("회원코드 : ");
      patientNoLabel.setFont(new Font("돋음", Font.BOLD, 20));
      patientNoLabel.setBounds(200, 113, 110, 80);
      patientNoText = new JTextField();
      patientNoText.setBounds(310, 140, 80, 30);
      northPane.add(patientNoLabel);
      northPane.add(patientNoText);
      
      JLabel patientSsnLabel = new JLabel("주민등록번호 : ");
      patientSsnLabel.setFont(new Font("돋음", Font.BOLD, 20));
      patientSsnLabel.setBounds(410, 113, 150, 80);
      patientSsnText = new JTextField();
      patientSsnText.setBounds(560, 140, 160, 30);
      northPane.add(patientSsnLabel);
      northPane.add(patientSsnText);
      
      JLabel patientPhoneLabel = new JLabel("전화번호 : ");
      patientPhoneLabel.setFont(new Font("돋음", Font.BOLD, 20));
      patientPhoneLabel.setBounds(730, 113, 130, 80);
      patientPhoneText = new JTextField();
      patientPhoneText.setBounds(840, 140, 140, 30);
      northPane.add(patientPhoneLabel);
      northPane.add(patientPhoneText);
      
      
      
      
      
      JButton searchBtn = new JButton("검색");
      searchBtn.addActionListener(new SearchBtnEvent());
      searchBtn.setBounds(990, 130, 80, 50);
      northPane.add(searchBtn);
      
   
      
      
      JPanel southPane = new JPanel();
      southPane.setBackground(Color.WHITE);
      southPane.setBounds(0, 200, 1100, 500);
      
      listTable = new JTable(displayList());
      JScrollPane tablePane = new JScrollPane(listTable);
      listTable.setFillsViewportHeight(true);
      listTable.setAutoCreateRowSorter(true);
      
      
      tablePane.setPreferredSize(new Dimension(1050, 200));
      
      
      
      southPane.add(tablePane);
      
      
      backBtn = new JButton("뒤로가기");
      backBtn.addActionListener(this);
      backBtn.setBounds(530, 600, 300, 170);
      southPane.add(backBtn);
      
      totalPane.add(northPane);
      totalPane.add(southPane);
      this.add(totalPane);
      
      this.setResizable(false);
      this.setVisible(true);
      
   }
   
   private TableModel displayList(){
      
      String[] columnNames = {"No", "회원코드", "이름", "성별", "주민등록번호", "전화번호", "이메일", "주소"};
      Object[][] data = null;
      ArrayList<Patient> patient = new PatientController().selectList();
      
      data = new Object[patient.size()][8];
      for(int i = 0; i < patient.size(); i++){
      data[i][0] = null;
      data[i][1] = null;
      data[i][2] = null;
      data[i][3] = null;
      data[i][4] = null;
      data[i][5] = null;
      data[i][6] = null;
      data[i][7] = null;
      }
      dataModel = new DefaultTableModel(data, columnNames);
      return dataModel;
   }
   
   private TableModel displayListPatientName(){
      
      // 제목행
      String[] columnNames = {"No.", "회원코드", "이름", "성별", "주민등록번호", "전화번호", "이메일", "주소"};
      Object[][] data = null;
      ArrayList<Patient> patient = new PatientController().selectName(patientNameText.getText());
      
      if(patient == null){
         JOptionPane.showMessageDialog(null, "해당 이름을 가진 환자가 없습니다.", "경고", JOptionPane.ERROR_MESSAGE);
         return displayList();
      }
      data = new Object[patient.size()][8];
      char gender;
      for(int i = 0; i < patient.size(); i++){
         Patient pat = patient.get(i);
         if(pat.getPatSsn().substring(7, 8).equals("1")){
            gender = '남';
         }else {
            gender = '여';
         }
         data[i][0] = i+1;
         data[i][1] = pat.getPatNo();
         data[i][2] = pat.getPatName();
         data[i][3] = gender;
         data[i][4] = pat.getPatSsn();
         data[i][5] = pat.getPatPhone();
         data[i][6] = pat.getPatEmail();
         data[i][7] = pat.getPatAddress();
      }
      dataModel = new DefaultTableModel(data, columnNames);
      return dataModel;
   }
private TableModel displayListPatientNo(){
      
      // 제목행
      String[] columnNames = {"No.", "회원코드", "이름", "성별", "주민등록번호", "전화번호", "이메일", "주소"};
      Object[][] data = null;
      ArrayList<Patient> patient = new PatientController().selectNo(patientNoText.getText());
      
      if(patient == null){
         JOptionPane.showMessageDialog(null, "해당 회원번호를 가진 환자가 없습니다.", "경고", JOptionPane.ERROR_MESSAGE);
         return displayList();
      }
      data = new Object[patient.size()][8];
      char gender;
      for(int i = 0; i < patient.size(); i++){
         Patient pat = patient.get(i);
         if(pat.getPatSsn().substring(7, 8).equals("1")){
            gender = '남';
         }else {
            gender = '여';
         }
         data[i][0] = i+1;
         data[i][1] = pat.getPatNo();
         data[i][2] = pat.getPatName();
         data[i][3] = gender;
         data[i][4] = pat.getPatSsn();
         data[i][5] = pat.getPatPhone();
         data[i][6] = pat.getPatEmail();
         data[i][7] = pat.getPatAddress();
      }
      dataModel = new DefaultTableModel(data, columnNames);
      return dataModel;
   }
private TableModel displayListPatientSsn(){
   
   // 제목행
   String[] columnNames = {"No.", "회원코드", "이름", "성별", "주민등록번호", "전화번호", "이메일", "주소"};
   Object[][] data = null;
   ArrayList<Patient> patient = new PatientController().selectSsn(patientSsnText.getText());
   
   if(patient == null){
      JOptionPane.showMessageDialog(null, "해당 주민등록번호를 가진 환자가 없습니다.", "경고", JOptionPane.ERROR_MESSAGE);
      return displayList();
   }
   data = new Object[patient.size()][8];
   char gender;
   for(int i = 0; i < patient.size(); i++){
      Patient pat = patient.get(i);
      if(pat.getPatSsn().substring(7, 8).equals("1")){
         gender = '남';
      }else {
         gender = '여';
      }
      data[i][0] = i+1;
      data[i][1] = pat.getPatNo();
      data[i][2] = pat.getPatName();
      data[i][3] = gender;
      data[i][4] = pat.getPatSsn();
      data[i][5] = pat.getPatPhone();
      data[i][6] = pat.getPatEmail();
      data[i][7] = pat.getPatAddress();
   }
   dataModel = new DefaultTableModel(data, columnNames);
   return dataModel;
}
private TableModel displayListPatientPhone(){
   
   // 제목행
   String[] columnNames = {"No.", "회원코드", "이름", "성별", "주민등록번호", "전화번호", "이메일", "주소"};
   Object[][] data = null;
   ArrayList<Patient> patient = new PatientController().selectPhone(patientPhoneText.getText());
   
   if(patient == null){
      JOptionPane.showMessageDialog(null, "해당 전화번호를 가진 환자가 없습니다.", "경고", JOptionPane.ERROR_MESSAGE);
      return displayList();
   }
   data = new Object[patient.size()][8];
   char gender;
   for(int i = 0; i < patient.size(); i++){
      Patient pat = patient.get(i);
      if(pat.getPatSsn().substring(7, 8).equals("1")){
         gender = '남';
      }else {
         gender = '여';
      }
      data[i][0] = i+1;
      data[i][1] = pat.getPatNo();
      data[i][2] = pat.getPatName();
      data[i][3] = gender;
      data[i][4] = pat.getPatSsn();
      data[i][5] = pat.getPatPhone();
      data[i][6] = pat.getPatEmail();
      data[i][7] = pat.getPatAddress();
   }
   dataModel = new DefaultTableModel(data, columnNames);
   return dataModel;
}
private TableModel displayListPatientTotal(){
   
   // 제목행
   String[] columnNames = {"No.", "회원코드", "이름", "성별", "주민등록번호", "전화번호", "이메일", "주소"};
   Object[][] data = null;
   ArrayList<Patient> patient = new PatientController().selectSsn(patientSsnText.getText());
   Patient patInfo = patient.get(0);
   
   String total = patientNameText.getText() + patientNoText.getText() + patientSsnText.getText()
            + patientPhoneText.getText();
   
   String st = patInfo.getPatName() + patInfo.getPatNo() + patInfo.getPatSsn() + patInfo.getPatPhone();
   
   if(patient == null){
      JOptionPane.showMessageDialog(null, "해당 정보를 가진 환자가 없습니다.", "경고", JOptionPane.ERROR_MESSAGE);
      return displayList();
   }
   
   data = new Object[patient.size()][8];
   char gender;
   for(int i = 0; i < patient.size(); i++){
      Patient pat = patient.get(i);
      if(pat.getPatSsn().substring(7, 8).equals("1")){
         gender = '남';
      }else {
         gender = '여';
      }
      data[i][0] = i+1;
      data[i][1] = pat.getPatNo();
      data[i][2] = pat.getPatName();
      data[i][3] = gender;
      data[i][4] = pat.getPatSsn();
      data[i][5] = pat.getPatPhone();
      data[i][6] = pat.getPatEmail();
      data[i][7] = pat.getPatAddress();
    }
   
   dataModel = new DefaultTableModel(data, columnNames);
   if(total.equals(st)){
      return dataModel;
   }
   return displayList();
}
   
   private class SearchBtnEvent implements ActionListener {
      @Override
      public void actionPerformed(ActionEvent e){
         if(patientNameText.getText() != null && patientNameText.getText().length() > 0){
            if((patientNoText.getText() == null || patientNoText.getText().length() == 0) && (
                  patientSsnText.getText() == null || patientSsnText.getText().length() == 0) && (
                        patientPhoneText.getText() == null || patientPhoneText.getText().length() == 0)){
               listTable.setModel(displayListPatientName());
            }
         }
         if(patientNoText.getText() != null && patientNoText.getText().length() > 0){
            if((patientNameText.getText() == null || patientNameText.getText().length() == 0) && (
                  patientSsnText.getText() == null || patientSsnText.getText().length() == 0) && (
                        patientPhoneText.getText() == null || patientPhoneText.getText().length() == 0)){
               listTable.setModel(displayListPatientNo());
            }
         }
         if(patientSsnText.getText() != null && patientSsnText.getText().length() > 0){
            if((patientNameText.getText() == null || patientNameText.getText().length() == 0) && (
                  patientNoText.getText() == null || patientNoText.getText().length() == 0) && (
                        patientPhoneText.getText() == null || patientPhoneText.getText().length() == 0)){
               listTable.setModel(displayListPatientSsn());
            }
         }
         if(patientPhoneText.getText() != null && patientPhoneText.getText().length() > 0){
            if((patientNameText.getText() == null || patientNameText.getText().length() == 0) && (
                  patientNoText.getText() == null || patientNoText.getText().length() == 0) && (
                        patientSsnText.getText() == null || patientSsnText.getText().length() == 0)){
               listTable.setModel(displayListPatientPhone());
            }
         }
         if(patientPhoneText.getText() != null && patientPhoneText.getText().length() > 0){
            if(patientNameText.getText() != null && patientNameText.getText().length() > 0){
               if(patientNoText.getText() != null && patientNoText.getText().length() > 0){
                  if(patientSsnText.getText() != null && patientSsnText.getText().length() > 0){
                     listTable.setModel(displayListPatientTotal());
                  }
               }
            }
      }
   }
   }   
   @Override
   public void actionPerformed(ActionEvent e){
      if(e.getSource() == backBtn){
         this.setVisible(false);
      }
   }
}