//DChatView

package mms.view;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class DChatView extends JDialog implements ActionListener{
   
   private JTextArea tarea;
   private JTextField tfield;
   private JButton sendBtn;
   
   private DataOutputStream out;
   private DataInputStream in;
   private Socket socket;
   
   public final int portNo = 9476;
   public final String serverIP = "192.168.30.69";
   
   public DChatView(){
      
      this.setTitle("MMS");
      this.setBounds(700,200,500,500);
      Font textFont = new Font("굴림체", Font.PLAIN, 14);
      
      // 아이콘 설정
      Toolkit tk = Toolkit.getDefaultToolkit();
      Image icon = tk.getImage("image/mms_icon.png");
      this.setIconImage(icon);
      
      JPanel northPan = new JPanel();
      JLabel titleLabel = new JLabel("1:1 상담(관리자)");
      titleLabel.setFont(new Font("굴림체", Font.BOLD, 30));
      northPan.add(titleLabel);
      
      tarea = new JTextArea();
      tarea.setSize(490, 400);
      tarea.setFont(textFont);
      JScrollPane chatPane = new JScrollPane(tarea);
      
      JPanel southPan = new JPanel();
      tfield = new JTextField(50);
      tfield.setFont(textFont);
      JLabel gap = new JLabel("        ");
      sendBtn = new JButton("전송");
      sendBtn.addActionListener(this);
      tfield.addKeyListener(new KeyListener() {
  		
		@Override
		public void keyTyped(KeyEvent e) {}
		
		@Override
		public void keyReleased(KeyEvent e) {}
		
		
		//엔터 입력시 전송
		@Override
		public void keyPressed(KeyEvent e) {
			if(e.getKeyCode() == KeyEvent.VK_ENTER){
				String time = new SimpleDateFormat("a hh:mm").format(new Date());	   
			       try {
					out.writeUTF("[" + time + "] 관리자:" + tfield.getText() + "\n");
					//전송 후 필드값 지우기
			        tfield.setText("");
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "전송 실패", "오류 발생", JOptionPane.ERROR_MESSAGE);
				}
			}
			
		}
	});
      
      southPan.add(tfield);
      southPan.add(gap);
      southPan.add(sendBtn);      
      
      
      this.add(northPan, BorderLayout.NORTH);
      this.add(chatPane, BorderLayout.CENTER);
      this.add(southPan, BorderLayout.SOUTH);
      
      
      tarea.append("상담 대기 상태입니다.\n");
      
      connect();
      
      this.setVisible(true);
   }
   
   //전송버튼 클릭시 이벤트
   @Override
   public void actionPerformed(ActionEvent event) {
	   String time = new SimpleDateFormat("a hh:mm").format(new Date());	   
       try {
		out.writeUTF("[" + time + "] 관리자:" + tfield.getText() + "\n");
		//전송 후 필드값 지우기
        tfield.setText("");
	} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "전송 실패", "오류 발생", JOptionPane.ERROR_MESSAGE);
	}
   }
   
   
   // 연결
   public void connect(){      
      try {
         socket = new Socket(serverIP, portNo);
         tarea.append("서버와 연결되었습니다.\n");
         
         Thread receiver = new Thread(new ClientReceiver());
         Thread sender = new Thread(new ClientSender());
         sender.start();
         receiver.start();
         
      } catch (IOException e) {
    	  JOptionPane.showMessageDialog(null, "서버 연결 실패", "오류 발생", JOptionPane.ERROR_MESSAGE);
      }
      
   }//connect close
   
   //메세지 전송 스레드 내부클래스
   public class ClientSender implements Runnable{  
      public ClientSender(){
         try {
            out = new DataOutputStream(socket.getOutputStream());
         } catch (Exception e) {
        	 JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
         }
      }

      @Override
      public void run() {
    	  
         if(out != null){ //NullpointException 처리용
            try {
            	out.writeUTF("관리자");            	
            } catch (Exception e) {
            	JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
            }
         }//if close         
      }
   }//inner class close
   
   //메세지 수신 스레드 내부클래스
   public class ClientReceiver implements Runnable{
      
      public ClientReceiver(){
         try {
            in = new DataInputStream(socket.getInputStream());
         } catch (Exception e) {
        	 JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
         }
      }

      @Override
      public void run() {
         while(in != null){
            try {
               tarea.append(in.readUTF());
               tarea.setCaretPosition(tarea.getDocument().getLength());
            } catch (Exception e) {
            	JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);;
            }
         }//while close
         
      }
      
   }//inner class close
   
}