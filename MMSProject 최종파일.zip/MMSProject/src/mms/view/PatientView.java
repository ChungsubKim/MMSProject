package mms.view;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PatientView extends JFrame implements ActionListener{
   private JPanel panel;
   private JLabel mainLabel;
   private JButton appBtn, chatBtn, myinfoBtn, backBtn;
   private ImageIcon mainLogo, main_logo, m_logo, appImageBtn, chatImageBtn, myinfoImageBtn, backImageBtn;
   private Image image1, icon;

   //private Patient pat;
   private String id;
   
   public PatientView(String id){ // 생성자
      this.setTitle("MMS");      
      this.setBounds(200, 200, 400, 600);
      this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
      
      //this.pat = pat; // 로그인 객체
      this.id = id;
      
      // 아이콘 설정
      Toolkit tk = Toolkit.getDefaultToolkit();
      icon = tk.getImage("image/mms_icon.png");
      this.setIconImage(icon);
      
      panel = new JPanel();
      panel.setBackground(Color.white);
      panel.setLayout(null);
      
      mainLogo = new ImageIcon("image/logo.png");
      // image 크기 조절해 새로운 객체생성
      image1 = mainLogo.getImage().getScaledInstance(300, 100, Image.SCALE_SMOOTH);
      // 다시 ImageIcon 객체 생성
      main_logo = new ImageIcon(image1);
      mainLabel = new JLabel(main_logo);
      mainLabel.setBounds(40, 70, 300, 100);
      panel.add(mainLabel);
      
      appImageBtn = new ImageIcon("image/app.png");
      appBtn = new JButton(appImageBtn);
      appBtn.setBounds(70,190,120,150);
      appBtn.addActionListener(this);
      
      chatImageBtn = new ImageIcon("image/chat.png");
      chatBtn = new JButton(chatImageBtn);
      chatBtn.setBounds(200,190,120,150);
      chatBtn.addActionListener(this);
      
      myinfoImageBtn = new ImageIcon("image/myinfo.png");
      myinfoBtn = new JButton(myinfoImageBtn);
      myinfoBtn.setBounds(70,350,120,150);
      myinfoBtn.addActionListener(this);
      
      backImageBtn = new ImageIcon("image/logout.png");
      backBtn = new JButton(backImageBtn);
      backBtn.setBounds(200, 350, 120, 150);
      backBtn.setBackground(Color.WHITE);
      backBtn.addActionListener(this);
      
      panel.add(appBtn);
      panel.add(chatBtn);
      panel.add(myinfoBtn);      
      panel.add(backBtn);
      
      this.add(panel);
      this.setResizable(false);
   }

   @Override
   public void actionPerformed(ActionEvent e) {
      if(e.getSource() == appBtn){
         new AppointmentView(this.id).setVisible(true);
      }
      else if(e.getSource() == chatBtn){
         new PChatView(this.id).setVisible(true);
      }
      else if(e.getSource() == myinfoBtn){
         new UpdateView(this.id).setVisible(true);
      }
      else if(e.getSource() == backBtn) {
         new LoginView();
         this.setVisible(false);
      }
   }
}
