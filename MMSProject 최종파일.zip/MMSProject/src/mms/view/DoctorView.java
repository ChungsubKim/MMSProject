//DoctorView

package mms.view;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DoctorView extends JFrame implements ActionListener{
   private JPanel panel;
   private ImageIcon originLogo, logo, scheduleImageBtn, psearchImageBtn, dsearchImageBtn, backImageBtn;
   private Image image, changeImage, icon;
   private JLabel imageLabel;
   private JButton scheduleBtn, psearchBtn, dsearchBtn, backBtn;
   
   public DoctorView(){
      this.setTitle("관리자 메뉴");
      this.setBounds(200, 200, 400, 600);
      this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
      
      //아이콘 설정
      Toolkit tk = Toolkit.getDefaultToolkit();
      icon = tk.getImage("image/mms_icon.png");
      this.setIconImage(icon);
      
      panel = new JPanel();
      panel.setBackground(Color.WHITE);
      panel.setLayout(null);
      
      originLogo = new ImageIcon("image/logo.png");
      image = originLogo.getImage();         //ImageIcon에서 image추출
      changeImage = image.getScaledInstance(300, 100, Image.SCALE_SMOOTH);    // image 크기 조절해 새로운 객체생성
      logo = new ImageIcon(changeImage); // 다시 ImageIcon 객체 생성
      imageLabel = new JLabel(logo);
      imageLabel.setBounds(40, 70, 300, 100);
      panel.add(imageLabel);
      
      scheduleImageBtn = new ImageIcon("image/schedule.png");
      scheduleBtn = new JButton(scheduleImageBtn);
      scheduleBtn.setBackground(Color.WHITE);
      scheduleBtn.setBounds(70,190,120,150);
      scheduleBtn.addActionListener(this);
      
      
      psearchImageBtn = new ImageIcon("image/psearch.png");
      psearchBtn = new JButton(psearchImageBtn);
      psearchBtn.setBackground(Color.WHITE);
      psearchBtn.setBounds(200,190,120,150);
      psearchBtn.addActionListener(this);
      
      dsearchImageBtn = new ImageIcon("image/dsearch.png");
      dsearchBtn = new JButton(dsearchImageBtn);
      dsearchBtn.setBackground(Color.WHITE);
      dsearchBtn.setBounds(70,350,120,150);
      dsearchBtn.addActionListener(this);
      
      backImageBtn = new ImageIcon("image/logout.png");
      backBtn = new JButton(backImageBtn);
      backBtn.setBounds(200, 350, 120, 150);
      backBtn.setBackground(Color.white);
      backBtn.addActionListener(this);
      
      
      panel.add(scheduleBtn);
      panel.add(psearchBtn);
      panel.add(dsearchBtn);
      //panel.add(mLabel);
      panel.add(backBtn);
      
      this.add(panel);
      this.setVisible(false);

   }
   
   @Override
   public void actionPerformed(ActionEvent event) {
      if(event.getSource() == scheduleBtn){
         new ScheduleView().setVisible(true);
      }
      else if(event.getSource() == psearchBtn){
         new PSearchView().setVisible(true);
      }
      else if(event.getSource() == dsearchBtn){
         new DSearchView().setVisible(true);
      }
      else if(event.getSource() == backBtn){
         new LoginView().setVisible(true);
         this.setVisible(false);
         
      }
   }
}