package mms.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import mms.controller.AppointmentController;
import mms.controller.DoctorController;
import mms.controller.PatientController;
import mms.model.dto.Appointment;
import mms.model.dto.Patient;

public class AppointmentView extends JFrame implements ActionListener{

   private AppointmentController aControll = new AppointmentController();
   private PatientController pControll = new PatientController();
   private DoctorController dControll = new DoctorController();
   
   private JTable table;
   private TableModel model;
   private JScrollPane tablePane;   
   private JPanel appPane;
   private JTextField tfNote;
   private JComboBox<String> cbYear, cbMonth, cbDay, cbHour;
   private JComboBox<Object> cbDept, cbDoc;
   private JButton backBtn, bookBtn, deleteBtn;
   private JRadioButton yesBtn,noBtn;
      
   private String id;
   private Patient pat;

   public AppointmentView(String id){     
	   this.id = id;
	   pat = pControll.selectPatient(id);
	    
	   this.setTitle("MMS"); 	
	   this.setBounds(new Rectangle(1000,700));
	   this.setResizable(true);
	   this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
	   
	   // 아이콘 설정
	   Toolkit tk = Toolkit.getDefaultToolkit();
	   Image icon = tk.getImage("image/mms_icon.png");
	   this.setIconImage(icon);
	   
	   this.makeApp();
	   this.makeTable();
	    
	   this.add(appPane, BorderLayout.NORTH);
	   this.add(tablePane, BorderLayout.CENTER);
	   
	   JPanel backPane = new JPanel();
	   backPane.setLayout(new FlowLayout());
	   backBtn = new JButton("뒤로가기");
	   backBtn.addActionListener(this);
	   this.add(backBtn, BorderLayout.SOUTH);
	  
	   this.pack();
	   this.setVisible(true);
   }

   public void makeApp() {
	   this.appPane = new JPanel(new GridLayout(8,1));
	   this.appPane.setSize(new Dimension(200,400));
      
	   JPanel titlePane = new JPanel();
	   JLabel titleLabel = new JLabel("유저 예약/검색");
	   titleLabel.setFont(new Font("굴림체", Font.BOLD, 30));
	   titleLabel.setHorizontalAlignment(JLabel.LEFT);      
	   titlePane.add(titleLabel);
            
	   JPanel gap1 = new JPanel();
      
	   JPanel p1 = new JPanel();
	   p1.setLayout(new FlowLayout());
      
	   // 성별
	   char cGender = pat.getPatSsn().charAt(7);
	   String gender = null;
	   if(cGender=='2' || cGender=='4')
		   gender = "여";
	   else if(cGender=='1' || cGender=='3')
		   gender = "남";
	       
	   // 나이
	   char cAge = pat.getPatSsn().charAt(0);
	   int age = 0;
	   Calendar today = Calendar.getInstance();
	   int year = today.get(Calendar.YEAR);
	   if(cAge == '0' || cAge == '1')
		   age = 2000 + Integer.parseInt(pat.getPatSsn().substring(0, 2));
	   else
		   age = 1900 + Integer.parseInt(pat.getPatSsn().substring(0, 2));
	   JLabel myLabel = new JLabel("이름:"+pat.getPatName()+"  주민번호:"+pat.getPatSsn()
		                         +"  성별:"+gender+"  나이:(만)"+(year-age)+"세");
	   //JLabel myLabel = new JLabel("?????");
	   myLabel.setFont(new Font("굴림체", Font.BOLD, 15));
	   p1.add("West", myLabel);
	      
	   JPanel p2 = new JPanel();
	   p2.add(new JLabel("예약일     "));
	       
	   // 년, 월, 일
       String[] years = {"2018","2019","2020","2021","2022"};       
       
       cbYear = new JComboBox<String>(years);
       cbMonth = new JComboBox<String>();
       cbDay = new JComboBox<String>();
       cbYear.addActionListener(new ActionListener(){
    	   @Override
    	   public void actionPerformed(ActionEvent e) {   
    		   String[] months;
    		   int curYear = Calendar.getInstance().get(Calendar.YEAR); // 현재 년도	
    		   int curMonth = Calendar.getInstance().get(Calendar.MONTH)+1;
    		   int appYear = Integer.parseInt((String)cbYear.getSelectedItem()); // 예약 년도
  		  
    		   if(curYear==appYear){    	
    			   months = new String[12-curMonth+1];    	
    			   
    			   for(int i = 0 ; i<(12-curMonth+1); i++){
    				   months[i] = String.valueOf(curMonth + i);
    			   }    			   
    		   }    		   
    		   else{
    			   months = new String[12];
    				for(int i=0; i<12; i++){
    					months[i] = String.valueOf(i+1);
    				}    				
    		   }
    		   cbMonth.setModel(new DefaultComboBoxModel<String>(months));
    	   }    	   
       });
       
       cbMonth.addActionListener(new ActionListener(){
    	   @Override
    	   public void actionPerformed(ActionEvent e) {
    		   int count = 0;
			
    		   switch(Integer.parseInt((String)cbMonth.getSelectedItem())){ 
    		   case 1: case 3: case 5: case 7: case 8: case 10: case 12:
    			   count = 31;
    			   break;
    		   case 4: case 6: case 9: case 11:
    			   count = 30;
    			   break;
    		   default :
    			   count = 28;	
    		   }
    		   String[] days = new String[count];
    		   
    		   if( (Integer.parseInt((String)cbYear.getSelectedItem()) == Calendar.getInstance().get(Calendar.YEAR)) &&
      				(Integer.parseInt((String)cbMonth.getSelectedItem()) == (Calendar.getInstance().get(Calendar.MONTH)+1))  ){
    			   
    			   String[] days2 = new String[count-Calendar.getInstance().get(Calendar.DAY_OF_MONTH)];
    			   for(int i=0; i<days2.length; i++){    			
    				   days2[i] = String.valueOf(count-i);
    			   }
    			   cbDay.setModel(new DefaultComboBoxModel<String>(days2));
    		   }
    		   else{    		   
	    		   for(int i=0; i<days.length; i++){
	    			   days[i] = String.valueOf(i+1);
	    		   }
	    		   cbDay.setModel(new DefaultComboBoxModel<String>(days));
    		   }    		   
    	   }
       });
       
       p2.add(cbYear);
       p2.add(new JLabel("년  "));
       p2.add(cbMonth);
       p2.add(new JLabel("월  "));   
	   p2.add(cbDay);
	   p2.add(new JLabel("일  "));      
	   
	   
	   // 시
	   String[] hours = {"10", "11", "12", "14", "15", "16"};
	   cbHour = new JComboBox<String>(hours);
	   p2.add(cbHour);      
	   p2.add(new JLabel("시"));
	         
	   JPanel p3 = new JPanel();
	   p3.add(new JLabel("증상     "));
	   tfNote = new JTextField(30);
	   p3.add(tfNote);
	         
	   JPanel p4 = new JPanel();
	   
	   // 진료과
	   p4.add(new JLabel("진료과 "));
	   int deptSize = dControll.selectDeptAll().size();
	   Object[] depts= new Object[deptSize];
	   for(int i=0; i<deptSize; i++){
		   depts[i] = dControll.selectDeptAll().get(i).getDeptName();
	   }
	   cbDept = new JComboBox<>(depts);
	   p4.add(cbDept);
	   
	   // 담당의
	   p4.add(new JLabel("     담당의 "));
	   cbDoc = new JComboBox<>();
	   cbDept.addActionListener(new ActionListener(){  
		   @Override
		   public void actionPerformed(ActionEvent e) {
			   String select = (String)cbDept.getSelectedItem();
			   int docSize = dControll.selectDept(select).size();
			   Object[] docs = new Object[docSize];
			   for(int i=0; i<docSize; i++){
				   docs[i] = dControll.selectDept(select).get(i).getDocName();
			   }
			   cbDoc.setModel(new DefaultComboBoxModel<Object>(docs));
			   table.setModel(displayList());
		   }
	   });	   
	   p4.add(cbDoc);     
	       
	   JPanel p5 = new JPanel();
	   p5.add(new JLabel("초진 여부"));
	   yesBtn = new JRadioButton("예");
	   noBtn = new JRadioButton("아니오");
	   ButtonGroup group = new ButtonGroup();
	   group.add(yesBtn);
	   group.add(noBtn);
	   JLabel gap = new JLabel("                    ");
	   bookBtn = new JButton("예약");
	   bookBtn.setSize(new Dimension(40,10));
	   bookBtn.addActionListener(new BookBtnEvent());
	   deleteBtn = new JButton("삭제");
	   deleteBtn.setSize(new Dimension(40, 10));
	   deleteBtn.addActionListener(new DeleteBtnEvent());
	   p5.add(yesBtn);
	   p5.add(noBtn);
	   p5.add(gap);
	   p5.add(bookBtn);
	   p5.add(deleteBtn);
	   
	   appPane.add(titlePane);
	   appPane.add(gap1);
	   appPane.add(p1);
	   appPane.add(p2);
	   appPane.add(p3);
	   appPane.add(p4);      
	   appPane.add(p5);
   }
   
   public void makeTable() {
	   table = new JTable(displayList());
	   this.tablePane = new JScrollPane(table);
	   
	   this.table.setFillsViewportHeight(true); // 창 크기에 맞추기
	   this.table.setAutoCreateRowSorter(true); // 행 자동 정렬
   }

   // 컨트롤러와 연결해서 요청한 결과 데이터 받는 메소드 작성
   // 전체 조회시 결과를 TableModel로 만들어 리턴처리함
   public TableModel displayList() {         
       // 제목행 정의
       String columnNames[] = {"No.", "진료일시", "회원명", "의사명", "부서명", "증상", "초진여부"};
       
       Object[][] data = null;      
       
       ArrayList<Object[]> list = aControll.selectPatList(id);
       if(list == null){
          model = new DefaultTableModel(data, columnNames);
       }
       else{
          data = new Object[list.size()][];
       
          for(int i=0; i<list.size(); i++){
             data[i] = new Object[7];
             
             data[i][0] = list.get(i)[0];
             data[i][1] = list.get(i)[1];
             data[i][2] = list.get(i)[2];
             data[i][3] = list.get(i)[3];
             data[i][4] = list.get(i)[4];
             data[i][5] = list.get(i)[5];
             data[i][6] = list.get(i)[6];

       } 
          model = new DefaultTableModel(data, columnNames);
       }
       return model;
    }

   @Override
   public void actionPerformed(ActionEvent e) {
	   if(e.getSource() == backBtn){ // 뒤로가기 클릭시 적용되는 이벤트 처리
		   this.setVisible(false);
	   }
   }
   
   // 예약하기 클릭시 적용되는 이벤트 처리 클래스
   public class BookBtnEvent implements ActionListener{

      @Override
      public void actionPerformed(ActionEvent e) {            
         Appointment app = new Appointment();      
         // app_no : 시퀀스값
      
        String year = (String)cbYear.getSelectedItem();
        String month = (String)cbMonth.getSelectedItem();
        String day = (String)cbDay.getSelectedItem();
        String hour = (String)cbHour.getSelectedItem();
         
        String appDate = year + "-" + month + "-" + day + " " + hour + ":00";           
        app.setAppDate(appDate);
        
        app.setPatNo(pat.getPatNo());
        String first = null;            
        if(yesBtn.isSelected())
           first = "Y";
        else if(noBtn.isSelected())
           first = "N";
        app.setAppFirst(first);
        
        app.setDeptNo(aControll.selectDeptNo((String)cbDept.getSelectedItem()));
        app.setDocNo(aControll.selectDocNo((String)cbDoc.getSelectedItem()));
       
        app.setAppMemo(tfNote.getText());
        
        if(Calendar.getInstance().get(Calendar.YEAR) >= Integer.parseInt((String)cbYear.getSelectedItem())){        	
           if((Calendar.getInstance().get(Calendar.MONTH)+1) >= Integer.parseInt((String)cbMonth.getSelectedItem())){
              if((Calendar.getInstance().get(Calendar.DAY_OF_MONTH)) >= Integer.parseInt((String)cbDay.getSelectedItem())){
            	  if((Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) >= Integer.parseInt((String)cbHour.getSelectedItem())){
                 
                    JOptionPane.showMessageDialog(null, "날짜 및 시간을 확인해주세요"); 
                    
                 }else {
                     if(aControll.insertAppointment(app) > 0) {
                         table.setModel(displayList());
                      }           
                    }                                  
              }else {
                  if(aControll.insertAppointment(app) > 0) {
                      table.setModel(displayList());
                   }           
                 }
           }else {
               if(aControll.insertAppointment(app) > 0) {
                   table.setModel(displayList());
                }           
              }
           
        }else {
        if(aControll.insertAppointment(app) > 0) {
           table.setModel(displayList());
        }           
      }
   }
   }
   
   // 삭제버튼 클릭시 적용되는 이벤트 처리 클래스
   public class DeleteBtnEvent implements ActionListener{
	 
	   @Override
	   public void actionPerformed(ActionEvent e) {         
		   for(int i=0; i<table.getRowCount(); i++){
			   int row = table.getSelectedRow();
			   if(table.isRowSelected(row)){
				   if(aControll.deleteAppointment((String) table.getValueAt(row, 0)) > 0){
					   table.setModel(displayList());
				   }
			   }
		   }
	   }
   }
}