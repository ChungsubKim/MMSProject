package mms.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import mms.controller.AppointmentController;
import mms.controller.DoctorController;

public class ScheduleView extends JFrame implements ActionListener {
   private JPanel totalPane;
   private JTable listTable;
   private TableModel dataModel;
   private JTextField deptNameText, doctorNameText;
   private JButton backBtn;
   private JLabel docNameText;
   private Image icon;
   
   public ScheduleView() {
      this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
       this.setTitle("스케줄");
       this.setBounds(100, 100, 900, 600);
       this.setResizable(false);
       
       Toolkit tk = Toolkit.getDefaultToolkit();
       icon = tk.getImage("image/mms_icon.png");
       this.setIconImage(icon);
       
       viewInit();
       addComponent();
       this.add(totalPane);
       this.setVisible(true);
   }
   
   private void viewInit() {
      listTable = new JTable();
      
      totalPane = new JPanel();
      totalPane.setBackground(Color.WHITE);
       totalPane.setLayout(null);
       
       backBtn = new JButton("뒤로가기");
       backBtn.addActionListener(this);
       backBtn.setBounds(385, 510, 90, 25);
   }
   
   private void addComponent() {
      totalPane.add(new northPanel().getJPanel());
      totalPane.add(new centerPanel().getJPanel());
      totalPane.add(new southPanel().getJPanel());
      totalPane.add(backBtn);
   }
   
   // northPanel inner class
   private class northPanel implements ActionListener {
      JPanel northPane = new JPanel();
      JLabel deptNameLabel, doctorNameLabel, doctorRoomLabel, doctorRoomInfoLabel;
      JButton searchBtn;
      
      public northPanel() {
         northPane.setBackground(Color.WHITE);
          northPane.setBounds(0, 0, 900, 150);
          northPane.setLayout(null);
          
          northPaneinit();
          addComponent();
      }
      
      private void northPaneinit() {
         deptNameLabel = new JLabel("진료과 : ");
          deptNameLabel.setFont(new Font("돋음", Font.BOLD, 25));
          deptNameLabel.setBounds(10, 70, 100, 40);
            
          deptNameText = new JTextField();
          deptNameText.setBounds(110, 79, 130, 30);
            
          doctorNameLabel = new JLabel("의사명 : ");
          doctorNameLabel.setFont(new Font("돋음", Font.BOLD, 25));
          doctorNameLabel.setBounds(260, 70, 100, 40);
          
          doctorNameText = new JTextField();
          doctorNameText.setBounds(370, 79, 130, 30);
            
          doctorRoomLabel = new JLabel("진료실 : ");
          doctorRoomLabel.setFont(new Font("돋음", Font.BOLD, 25));
          doctorRoomLabel.setBounds(520, 70, 100, 40);
          
          doctorRoomInfoLabel = new JLabel(); // 수정
          doctorRoomInfoLabel.setFont(new Font("돋음", Font.BOLD, 25));
          doctorRoomInfoLabel.setBounds(620, 70, 100, 40);
          
          searchBtn = new JButton("검색");
          searchBtn.setBounds(740, 40, 90, 90);
          searchBtn.addActionListener(this);
      }
      
      private void addComponent() {
         northPane.add(deptNameLabel);
          northPane.add(deptNameText);
          northPane.add(doctorNameLabel);
          northPane.add(doctorNameText);
          northPane.add(doctorRoomLabel);
          northPane.add(doctorRoomInfoLabel);
          northPane.add(searchBtn);
      }
      
      
       
      private JPanel getJPanel() {
         return northPane;
      }

      @Override
      public void actionPerformed(ActionEvent event) {
         if(event.getSource() == searchBtn) {
            if(deptNameText.getText() != null && deptNameText.getText().length() > 0){
            	if(doctorNameText.getText() != null && doctorNameText.getText().length() > 0){
            		doctorRoomInfoLabel.setText(String.valueOf(getDoctorRoomInfo()));
                    docNameText.setText(doctorNameText.getText());
                    listTable.setModel(getTableModelAll());
            	}
            }
         }
      }
   }
   
   // centerPanel inner class
   private class centerPanel {
      JPanel centerPane = new JPanel();
      private JLabel scheduleText;
      
      public centerPanel() {
          centerPane.setBackground(Color.WHITE);
          centerPane.setBounds(0, 150, 900, 100);
          centerPane.setLayout(null);
          
          docNameText = new JLabel();
          docNameText.setFont(new Font("돋음", Font.BOLD,40));
          docNameText.setBounds(200, 20, 130, 70);
          
          scheduleText = new JLabel("님의  " + todayDate() + " 예약스케줄입니다.");
          scheduleText.setFont(new Font("돋음", Font.BOLD, 20));
          scheduleText.setBounds(330, 40, 400, 40);
          
          centerPane.add(docNameText);
          centerPane.add(scheduleText);
      }
      
      private JPanel getJPanel() {
         return centerPane;
      }
   }
   
   // southPanel inner class
   private class southPanel {
      JPanel southPane = new JPanel();
      
      public southPanel() {
          southPane.setBackground(Color.WHITE);
          southPane.setBounds(0, 250, 900, 250);
          
          listTable = new JTable(getTableModel());
           JScrollPane tablePane = new JScrollPane(listTable);
           listTable.setFillsViewportHeight(true);
           listTable.setAutoCreateRowSorter(true);
           
           tablePane.setPreferredSize(new Dimension(855, 240));
           southPane.add(tablePane);
      }
      
      private JPanel getJPanel() {
         return southPane;
      }
   }
   
   // etc methods
   private TableModel getTableModel(){
        String[] columnNames = {"No.", "환자명", "주민등록번호", "성별", "날짜","증상", "초진여부"};
        Object[][] data = new Object[1][7];
        
        for(int i = 0; i < data.length; i++)
           data[0][i] = null;
        
        dataModel = new DefaultTableModel(data, columnNames);
        return dataModel;
   }
   
   private TableModel getTableModelAll() {
	      String[] columnNames = {"No.", "환자명", "주민등록번호", "성별", "날짜", "증상", "초진여부"};
	      
	      Object[][] data = null;
	      ArrayList<Object[]> list =
	    		  new AppointmentController().selectDept(deptNameText.getText(), docNameText.getText());
	      
	      if(list == null){
	    	  dataModel = new DefaultTableModel(data, columnNames);
	      }
	      else{
	    	  data = new Object[list.size()][];
	    	  
	    	  for(int i=0; i<list.size(); i++){
	              data[i] = new Object[7];
	              
	              data[i][0] = list.get(i)[0];
	              data[i][1] = list.get(i)[1];
	              data[i][2] = list.get(i)[2];
	              data[i][3] = list.get(i)[3];
	              data[i][4] = list.get(i)[4];
	              data[i][5] = list.get(i)[5];
	              data[i][6] = list.get(i)[6];
	    	  }
	    	  dataModel = new DefaultTableModel(data, columnNames);
	      }	      
	      return dataModel;
	   }
   
   private String todayDate(){
         DateFormat sdFormat = new SimpleDateFormat("yyyy/MM/dd");
         Date nowDate = new Date();
         String tempDate = sdFormat.format(nowDate);
         return tempDate;
   }
   
   private int getDoctorRoomInfo() {	
	   return new DoctorController().selectScheduleRoom(doctorNameText.getText());
   }
   

   // event
   @Override
   public void actionPerformed(ActionEvent event) {
      if(event.getSource() == backBtn) {
         this.setVisible(false);
      }
   }
}