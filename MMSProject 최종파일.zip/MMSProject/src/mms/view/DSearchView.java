package mms.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import mms.controller.DoctorController;
import mms.model.dto.Doctor;


public class DSearchView extends JFrame implements ActionListener{
   
   private TableModel dataModel;
   private JTextField nameText, deptNameText, doctorRoomText;
   private JTable listTable;
   private JButton backBtn;
   private Image icon;
   
   public DSearchView(){
      
      this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
      this.setTitle(" MMS 의료진 조회 및 추가/삭제");
      this.setBounds(100, 100, 1100, 700);
      
      Toolkit tk = Toolkit.getDefaultToolkit();
      icon = tk.getImage("image/mms_icon.png");
      this.setIconImage(icon);
      
      
      JPanel totalPane = new JPanel();
      totalPane.setLayout(null);
      
      
      JPanel northPane = new JPanel();
      northPane.setBackground(Color.WHITE);
      northPane.setBounds(0, 0, 1100, 200);
      northPane.setLayout(null);
      
      JPanel titlePane = new JPanel();
      JLabel titleLabel = new JLabel("의료진 조회 및 추가 / 삭제");
      titleLabel.setFont(new Font("돋음", Font.BOLD, 40));
      titlePane.add(titleLabel);
      titlePane.setBounds(0, 20, 600, 100);
      titlePane.setBackground(Color.WHITE);
      northPane.add(titlePane);
      
      JLabel nameLabel = new JLabel("의사명 : ");
      nameLabel.setFont(new Font("돋음", Font.BOLD, 20));
      nameLabel.setBounds(10, 113, 100, 80);
      nameText = new JTextField();
      nameText.setBounds(100, 140, 100, 30);
      northPane.add(nameLabel);
      northPane.add(nameText);
      
      JLabel deptNameLabel = new JLabel("진료과 : ");
      deptNameLabel.setFont(new Font("돋음", Font.BOLD, 20));
      deptNameLabel.setBounds(240, 113, 100, 80);
      deptNameText = new JTextField();
      deptNameText.setBounds(330, 140, 100, 30);
      northPane.add(deptNameLabel);
      northPane.add(deptNameText);
      
      JLabel doctorRoomLabel = new JLabel("진료실 : ");
      doctorRoomLabel.setFont(new Font("돋음", Font.BOLD, 20));
      doctorRoomLabel.setBounds(490, 113, 100, 80);
      doctorRoomText = new JTextField();
      doctorRoomText.setBounds(580, 140, 100, 30);
      northPane.add(doctorRoomLabel);
      northPane.add(doctorRoomText);
      
      JButton searchBtn = new JButton("조회");
      searchBtn.addActionListener(new SearchBtnEvent());
      searchBtn.setBounds(800, 130, 80, 50);
      northPane.add(searchBtn);
      
      JButton insertBtn = new JButton("추가");
      insertBtn.addActionListener(new InsertBtnEvent());
      insertBtn.setBounds(890, 130, 80, 50);
      northPane.add(insertBtn);
      
      JButton deleteBtn = new JButton("삭제");
      deleteBtn.addActionListener(new DeleteBtnEvent());
      deleteBtn.setBounds(980, 130, 80, 50);
      northPane.add(deleteBtn);
      
      
      
      
      
      
      
      JPanel southPane = new JPanel();
      southPane.setBackground(Color.WHITE);
      southPane.setBounds(0, 200, 1100, 500);
      
      listTable = new JTable(displayList());
      JScrollPane tablePane = new JScrollPane(listTable);
      listTable.setFillsViewportHeight(true);
      listTable.setAutoCreateRowSorter(true);
      
      tablePane.setPreferredSize(new Dimension(1050, 400));
      listTable.addMouseListener(new TableItemSelection());
      
      
      southPane.add(tablePane); 
      
      
      backBtn = new JButton("뒤로가기");
      backBtn.addActionListener(this);
      backBtn.setBounds(530, 600, 300, 170);
      southPane.add(backBtn);
      
      totalPane.add(northPane);
      totalPane.add(southPane);
      this.add(totalPane);
      
      this.setResizable(false);
      this.setVisible(true);
      
   }
   
   private TableModel displayList(){
      
      // 제목행
      String[] columnNames = {"의사번호", "의사명", "진료과", "진료실"};
      
      Object[][] data = null;
      ArrayList<Doctor> list = new DoctorController().selectList();
      data = new Object[list.size()][];
      
      for(int i = 0; i < list.size(); i++){
         
         data[i] = new Object[4];
         Doctor doctor = list.get(i);
         data[i][0] = doctor.getDocNo();
         data[i][1] = doctor.getDocName();
         data[i][2] = doctor.getDeptName();
         data[i][3] = doctor.getDocRoom();
      }
      
      dataModel = new DefaultTableModel(data, columnNames);
      return dataModel;
   }
   
   
   private TableModel displayListDocName(){
      
      String[] columnNames = {"의사번호", "의사명", "진료과", "진료실"};
      Object[][] data = null;
      ArrayList<Doctor> doctor = new DoctorController().selectName(nameText.getText());
      
      if(doctor == null){
         JOptionPane.showMessageDialog(null, "해당 의사명을 가진 의사가 존재하지않습니다.", "경고", JOptionPane.ERROR_MESSAGE);
         return displayList();
      }
      
      data = new Object[doctor.size()][4];
      
      for(int i = 0; i < doctor.size(); i++){
         Doctor doc = doctor.get(i);
         data[i][0] = doc.getDocNo();
         data[i][1] = doc.getDocName();
         data[i][2] = doc.getDeptName();
         data[i][3] = doc.getDocRoom(); 
      }
      dataModel = new DefaultTableModel(data, columnNames);
      return dataModel;
   }
   
private TableModel displayListDeptName(){
      
      String[] columnNames = {"의사번호", "의사명", "진료과", "진료실"};
      Object[][] data = null;
      ArrayList<Doctor> doctor = new DoctorController().selectDept(deptNameText.getText());
      
      if(doctor == null){
         JOptionPane.showMessageDialog(null, "해당 진료과에 의사가 존재하지않습니다.", "경고", JOptionPane.ERROR_MESSAGE);
         return displayList();
      }
      
      data = new Object[doctor.size()][4];
      
      for(int i = 0; i < doctor.size(); i++){
         Doctor doc = doctor.get(i);
         data[i][0] = doc.getDocNo();
         data[i][1] = doc.getDocName();
         data[i][2] = doc.getDeptName();
         data[i][3] = doc.getDocRoom(); 
      }
      dataModel = new DefaultTableModel(data, columnNames);
      return dataModel;
   }

      private TableModel displayListDoctorRoom(){
   
   String[] columnNames = {"의사번호", "의사명", "진료과", "진료실"};
   Object[][] data = null;
   ArrayList<Doctor> doctor = new DoctorController().selectRoom(doctorRoomText.getText());
   
   if(doctor == null){
      JOptionPane.showMessageDialog(null, "해당 진료실을 사용하는 의사가 존재하지않습니다.", "경고", JOptionPane.ERROR_MESSAGE);
      return displayList();
   }
   
   data = new Object[doctor.size()][4];
   
   for(int i = 0; i < doctor.size(); i++){
      Doctor doc = doctor.get(i);
      data[i][0] = doc.getDocNo();
      data[i][1] = doc.getDocName();
      data[i][2] = doc.getDeptName();
      data[i][3] = doc.getDocRoom(); 
   }
   dataModel = new DefaultTableModel(data, columnNames);
   return dataModel;
}
      
      private TableModel displayListTotal(){
         String[] columnNames = {"의사번호", "의사명", "진료과", "진료실"};
         Object[][] data = null;
         ArrayList<Doctor> doctor = new DoctorController().selectRoom(doctorRoomText.getText());
         Doctor docInfo = doctor.get(0);
         
         String total = nameText.getText() + deptNameText.getText() + doctorRoomText.getText();
         String st = docInfo.getDocName() + docInfo.getDeptName() + docInfo.getDocRoom();
         
         if(doctor == null){
            JOptionPane.showMessageDialog(null, "해당 정보를 가진 의사가 존재하지않습니다.", "경고", JOptionPane.ERROR_MESSAGE);
            return displayList();
         }
         
         data = new Object[doctor.size()][4];
         
         for(int i = 0; i < doctor.size(); i++){
            Doctor doc = doctor.get(i);
            data[i][0] = doc.getDocNo();
            data[i][1] = doc.getDocName();
            data[i][2] = doc.getDeptName();
            data[i][3] = doc.getDocRoom(); 
         }
         dataModel = new DefaultTableModel(data, columnNames);
         if(total.equals(st)){
         return dataModel;
         }
         return displayList();
      }
   
   private class SearchBtnEvent implements ActionListener{
      @Override
      public void actionPerformed(ActionEvent e){
         if(nameText.getText() != null && nameText.getText().length() > 0){
            if((deptNameText.getText() == null || deptNameText.getText().length() == 0) && (
                  doctorRoomText.getText() == null || doctorRoomText.getText().length() == 0)){
               listTable.setModel(displayListDocName());
            }
         }
         if(deptNameText.getText() != null && deptNameText.getText().length() > 0){
            if((nameText.getText() == null || nameText.getText().length() == 0) &&(
                  doctorRoomText.getText() == null || doctorRoomText.getText().length() == 0)){
               listTable.setModel(displayListDeptName());
            }
         }
         if(doctorRoomText.getText() != null && doctorRoomText.getText().length() > 0){
            if((nameText.getText() == null || nameText.getText().length() == 0) && (
                  deptNameText.getText() == null || deptNameText.getText().length() == 0)){
               listTable.setModel(displayListDoctorRoom());
            }
         }
         if(nameText.getText() != null && nameText.getText().length() > 0){
            if(deptNameText.getText() != null && deptNameText.getText().length() > 0){
               if(doctorRoomText.getText() != null && doctorRoomText.getText().length() > 0){
                  listTable.setModel(displayListTotal());
               }
            }
         }
         if(nameText.getText() == null || nameText.getText().length() == 0){
             if(deptNameText.getText() == null || deptNameText.getText().length() == 0){
                if(doctorRoomText.getText() == null || doctorRoomText.getText().length() == 0){
                   listTable.setModel(displayList());
                }
             }
          }
         /*if(nameText.getText() == null && nameText.getText().length() == 0){
            if(deptNameText.getText() == null || deptNameText.getText().length() == 0){
               if(doctorRoomText.getText() == null || doctorRoomText.getText().length() == 0){
                  listTable.setModel(displayList());
               }
            }
         }*/
      }
   }
      public class InsertBtnEvent implements ActionListener{
            @Override
            public void actionPerformed(ActionEvent e){
               Doctor doctor = new Doctor();
               
               doctor.setDocName(nameText.getText());
               String dN = null;
               if(deptNameText.getText().equals("내과")){
                  dN = "M01";
               }else if(deptNameText.getText().equals("외과")){
                  dN = "M02";
               }else if(deptNameText.getText().equals("산부인과")){
                  dN = "M03";
               }else if(deptNameText.getText().equals("성형외과")){
                  dN = "M04";
               }else if(deptNameText.getText().equals("안과")){
                  dN = "M05";
               }else if(deptNameText.getText().equals("정형외과")){
                  dN = "M06";
               }else if(deptNameText.getText().equals("피부과")){
                  dN = "M07";
               }else if(deptNameText.getText().equals("흉부외과")){
                  dN = "M08";
               }else if(deptNameText.getText().equals("이비인후과")){
                  dN = "M09";
               }else if(deptNameText.getText().equals("정신건강의학과")){
                  dN = "M10";
               }
               
               doctor.setDeptNo(dN);
               
               if(new DoctorController().insertDoctor(doctor) > 0){
                  listTable.setModel(displayList());
               }
            }
         
         
      }
     
      public class TableItemSelection extends MouseAdapter{
         @Override
         public void mouseClicked(MouseEvent e){
            int row = listTable.getSelectedRow();
            String doctorName = (String)listTable.getValueAt(row, 1);
            
     
            ArrayList<Doctor> doctor = new DoctorController().selectName(doctorName);
            
            
            Doctor doc = doctor.get(0);
//            System.out.println(doc);
            nameText.setText(doc.getDocName());
            deptNameText.setText(doc.getDeptName());
            doctorRoomText.setText(String.valueOf(doc.getDocRoom()));
         }
      }
      
      private class DeleteBtnEvent implements ActionListener{
         @Override
         public void actionPerformed(ActionEvent e){
            
            
            if(new DoctorController().DeleteDoctor(nameText.getText()) > 0){
               listTable.setModel(displayList());
            }
         }
      }
      
      
         @Override
         public void actionPerformed(ActionEvent e){
         if(e.getSource() == backBtn){
            this.setVisible(false);
         }
         }
      
   
}