package mms.controller;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import mms.model.dto.Appointment;
import mms.model.service.AppointmentService;

public class AppointmentController {
   private AppointmentService aService = new AppointmentService();
   
   public AppointmentController(){}
   
   public ArrayList<Appointment> selectList(){
      ArrayList<Appointment> list = null;
      
      try{
         list = aService.selectList();
      } catch(Exception e){
         JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
      }
      return list;
   }
   
   public ArrayList<Object[]> selectPatList(String patId){
      ArrayList<Object[]> list = null;
      
      try{
         list = aService.selectPatList(patId);
      } catch(Exception e){
         JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
      }
      return list;
   }
   
   public String selectDeptNo(String deptName){
      String deptNo = null;
      try{
         deptNo = aService.selectDeptNo(deptName);
      } catch(Exception e){
         JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
      }
      return deptNo;
   }
   
   public String selectDocNo(String docName){
      String docNo = null;
      try{
         docNo = aService.selectDocNo(docName);
      } catch(Exception e){
         JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
      }
      return docNo;
   }
   
   public ArrayList<Object[]> selectDept(String deptName, String docName) {
      ArrayList<Object[]> list = null;
      try {
         list = aService.selectDept(deptName, docName);
      } catch (Exception e) {
         JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
      }
      return list;
   }
   
   public int insertAppointment(Appointment a){
      int result = 0;
      try{
         result = aService.insertAppointment(a);
         if(result > 0)
        	 JOptionPane.showMessageDialog(null, "예약이 등록되었습니다.", "알림", JOptionPane.INFORMATION_MESSAGE);
//            System.out.println("예약이 등록되었습니다.");
      } catch(Exception e){
         JOptionPane.showMessageDialog(null, "예약 등록에 실패했습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
      }
      return result;
   }
   
   public int updateAppointment(Appointment a){
      int result = 0;
      try{
         result = aService.updateAppointment(a);
         if(result > 0)
        	 JOptionPane.showMessageDialog(null, "예약이 수정되었습니다.", "알림", JOptionPane.INFORMATION_MESSAGE);
//            System.out.println("예약이 수정되었습니다.");
      } catch(Exception e){
         JOptionPane.showMessageDialog(null, "예약 수정에 실패했습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
      }
      return result;
   }
	
	public int deleteAppointment(String appNo){
	      int result = 0;
	      try{
	         result = aService.deleteAppointment(appNo);
	         if(result > 0)
	        	 JOptionPane.showMessageDialog(null, "예약이 삭제되었습니다.", "알림", JOptionPane.INFORMATION_MESSAGE);
//	            System.out.println("예약이 삭제되었습니다.");
	      } catch(Exception e){
	         JOptionPane.showMessageDialog(null, "예약 삭제에 실패했습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
	      }
	      return result;
	   }   
	
	
}
