package mms.controller;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import mms.model.dto.Doctor;
import mms.model.service.DoctorService;

public class DoctorController {
	private DoctorService dService = new DoctorService();
	
	public DoctorController(){}
	
	public ArrayList<Doctor> selectList(){
		ArrayList<Doctor> list = null;
		
		try{
			list = dService.selectList();
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, "해당 정보가 없습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
		}		
		return list;
	}
	
	public ArrayList<Doctor> selectName(String docName){
		ArrayList<Doctor> list = null;
		try{
			list = dService.selectName(docName);
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, "해당 정보가 없습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
		}		
		return list;
	}
	
	public ArrayList<Doctor> selectDept(String deptName){
		ArrayList<Doctor> list = null;
		try{
			list = dService.selectDept(deptName);
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, "해당 정보가 없습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
		}		
		return list;
	}
	
	public ArrayList<Doctor> selectDeptAll(){
		ArrayList<Doctor> list = null;
		try {
			list = dService.selectDeptAll();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "해당 정보가 없습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
		}	
		return list;
	}
	
	public ArrayList<Doctor> selectDocNo(String docNo){
		ArrayList<Doctor> list = null;
		try {
			list = dService.selectDocNo(docNo);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "해당 정보가 없습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
		}	
		return list;
	}
			
	public ArrayList<Doctor> selectDocAll(String deptName){
		ArrayList<Doctor> list = null;
		try {
			list = dService.selectDocAll(deptName);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "해당 정보가 없습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
		}
		return list;
	}
	
	public ArrayList<Doctor> selectRoom(String docRoom){
		ArrayList<Doctor> list = null;
		try {
			list = dService.selectRoom(docRoom);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "해당 정보가 없습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
		}
		return list;
	}
	
	public int selectScheduleRoom(String docName){
		int docRoom = 0;
		try {
			docRoom = dService.selectScheduleRoom(docName);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "해당 정보가 없습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
		}
		return docRoom;
	}
	
	
	
	public int insertDoctor(Doctor d){
		int result = 0;
		
		try{
			result = dService.insertDoctor(d);
			if(result > 0)
				JOptionPane.showMessageDialog(null, "의사정보가 등록되었습니다.", "알림", JOptionPane.INFORMATION_MESSAGE);
//				System.out.println("의사정보가 등록되었습니다.");
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, "의사정보 등록이 실패했습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	public int UpdateDoctor(Doctor d){
		int result = 0;
		
		try{
			result = dService.updateDoctor(d);
			if(result > 0)
				JOptionPane.showMessageDialog(null, "의사정보가 수정되었습니다.", "알림", JOptionPane.INFORMATION_MESSAGE);
//				System.out.println("의사정보가 수정되었습니다.");
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, "의사정보 수정에 실패했습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	public int DeleteDoctor(String docName){
		int result = 0;
		
		try{
			result = dService.deleteDoctor(docName);
			if(result > 0)
				JOptionPane.showMessageDialog(null, "의사정보가 삭제되었습니다.", "알림", JOptionPane.INFORMATION_MESSAGE);
//				System.out.println("의사정보가 삭제되었습니다.");
			
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, "의사정보 삭제에 실패했습니다.", "오류 발생", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}

}
