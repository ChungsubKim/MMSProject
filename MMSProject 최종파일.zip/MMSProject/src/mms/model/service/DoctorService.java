package mms.model.service;

import static mms.common.JDBCTemplate.*;
import java.sql.Connection;
import java.util.ArrayList;

import mms.exception.MMSException;
import mms.model.dao.DoctorDao;
import mms.model.dto.Doctor;

public class DoctorService {
	private DoctorDao dDao = new DoctorDao();
	
	public DoctorService(){}
	
	public ArrayList<Doctor> selectList() throws MMSException{
		Connection conn = getConnection();
		ArrayList<Doctor> list = dDao.displayList(conn);
		close(conn);
		return list;
	}
	
	public ArrayList<Doctor> selectDept(String deptName) throws MMSException{
		Connection conn = getConnection();
		ArrayList<Doctor> list = dDao.displayDept(conn, deptName);
		close(conn);
		return list;
	}
	
	public ArrayList<Doctor> selectName(String docName) throws MMSException{
		Connection conn = getConnection();
		ArrayList<Doctor> list = dDao.displayName(conn, docName);
		close(conn);
		return list;
	}
	
	public ArrayList<Doctor> selectDeptAll() throws MMSException{
		Connection conn = getConnection();
		ArrayList<Doctor> list = dDao.displayDeptAll(conn);
		close(conn);
		return list;
	}
	
	public ArrayList<Doctor> selectDocNo(String docNo) throws MMSException{
		Connection conn = getConnection();
		ArrayList<Doctor> list = dDao.displayDocNo(conn, docNo);
		close(conn);
		return list;
	}
	
	public ArrayList<Doctor> selectDocAll(String deptName) throws MMSException{
		Connection conn = getConnection();
		ArrayList<Doctor> list = dDao.displayDocAll(conn, deptName);
		close(conn);
		return list;
	}
			
	public ArrayList<Doctor> selectRoom(String docRoom) throws MMSException{
		Connection conn = getConnection();
		ArrayList<Doctor> list = dDao.displayRoom(conn, docRoom);
		close(conn);
		return list;
	}
	
	   
	public int selectScheduleRoom(String docName) throws MMSException{	
		Connection conn = getConnection();	  
		int docRoom = dDao.displayScheduleRoom(conn, docName);
		close(conn);
		return docRoom;
	}

	public int insertDoctor(Doctor d) throws MMSException{
		Connection conn = getConnection();
		int result = dDao.displayInsert(conn, d);
		if(result > 0)
			commit(conn);
		else
			rollback(conn);
		return result;
	}
	public int updateDoctor(Doctor d) throws MMSException{
		Connection conn = getConnection();
		int result = dDao.displayUpdate(conn, d);
		if(result > 0)
			commit(conn);
		else
			rollback(conn);
		return result;
	}
	public int deleteDoctor(String docName) throws MMSException{
		Connection conn = getConnection();
		int result = dDao.displayDelete(conn, docName);
		if(result > 0)
			commit(conn);
		else
			rollback(conn);
		return result;
	}	
}