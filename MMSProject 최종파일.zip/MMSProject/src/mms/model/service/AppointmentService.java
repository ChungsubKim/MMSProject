package mms.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import mms.exception.MMSException;
import mms.model.dao.AppointmentDao;
import mms.model.dto.Appointment;
import static mms.common.JDBCTemplate.*;

public class AppointmentService {
   private AppointmentDao aDao = new AppointmentDao();
   
   public AppointmentService(){}
   
   public ArrayList<Appointment> selectList() throws MMSException{ // 전체 조회
      Connection conn = getConnection();
      ArrayList<Appointment> list = aDao.displayList(conn);
      close(conn);
      return list;
   }
   
   /*public ArrayList<Appointment> selectPatList(String patNo) throws MMSException{ // 전체 조회
      Connection conn = getConnection();
      ArrayList<Appointment> list = aDao.displayPatList(conn, patNo);
      close(conn);
      return list;
   }*/
   public ArrayList<Object[]> selectPatList(String patId) throws MMSException{ // 전체 조회
      Connection conn = getConnection();
      ArrayList<Object[]> list = aDao.displayPatList(conn, patId);
      close(conn);
      return list;
   }
   
   public String selectDeptNo(String deptName) throws MMSException{
      Connection conn = getConnection();
      String deptNo = aDao.displayDeptNo(conn, deptName);
      close(conn);
      return deptNo;
   }
   
   public String selectDocNo(String docName) throws MMSException{
      Connection conn = getConnection();
      String docNo = aDao.displayDocNo(conn, docName);
      close(conn);
      return docNo;
   }
   
   public ArrayList<Object[]> selectDept(String deptName, String docName) throws MMSException {
      Connection conn = getConnection();
      ArrayList<Object[]> list = aDao.displayDept(conn, deptName, docName);
      close(conn);
      return list;
   }
   
   public int insertAppointment(Appointment a) throws MMSException{
      Connection conn = getConnection();
      int result = aDao.displayInsert(conn, a);
      if(result > 0)
         commit(conn);
      else
         rollback(conn);
      return result;
   }      
   public int updateAppointment(Appointment a) throws MMSException{
      Connection conn = getConnection();
      int result = aDao.displayUpdate(conn, a);
      if(result > 0)
         commit(conn);
      else
         rollback(conn);
      return result;
   }   
	public int deleteAppointment(String appNo) throws MMSException{
	      Connection conn = getConnection();
	      int result = aDao.displayDelete(conn, appNo);
	      if(result > 0)
	         commit(conn);
	      else
	         rollback(conn);
	      return result;
	   }
}