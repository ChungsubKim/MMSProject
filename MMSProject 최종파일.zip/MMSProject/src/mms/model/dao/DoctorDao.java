package mms.model.dao;

import static mms.common.JDBCTemplate.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import mms.exception.MMSException;
import mms.model.dto.Doctor;

public class DoctorDao {
	public DoctorDao(){}
	
	public ArrayList<Doctor> displayList(Connection conn) throws MMSException { // 전체정보 출력
		ArrayList<Doctor> list = new ArrayList<Doctor>();
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "select * from doctor join department using(dept_no)";
		try{
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			while(rset.next()){
				Doctor d = new Doctor();
				d.setDocNo(rset.getString("doc_no"));
				d.setDocName(rset.getString("doc_name"));
				d.setDocRoom(rset.getInt("doc_room"));
				d.setDeptNo(rset.getString("dept_no"));
				d.setDeptName(rset.getString("dept_name"));
				
				list.add(d);
			}
			if(list.size()==0)
				throw new MMSException("의사 정보가 없습니다.");			
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		} finally{
			close(rset);
			close(stmt);
		}		
		return list;
	}
	
	public ArrayList<Doctor> displayName(Connection conn, String docName) throws MMSException{ // 의사 이름으로 조회
		ArrayList<Doctor> list = new ArrayList<Doctor>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String query = "select * from doctor join department using(dept_no) where doc_name like ?";
		
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, "%" + docName + "%");
			
			rset = pstmt.executeQuery();
			
			while(rset.next()){
				Doctor d = new Doctor();
				d.setDocNo(rset.getString("doc_no"));
				d.setDocName(rset.getString("doc_name"));
				d.setDocRoom(rset.getInt("doc_room"));
				d.setDeptNo(rset.getString("dept_no"));
				d.setDeptName(rset.getString("dept_name"));
				
				list.add(d);
			}
			if(list.size()==0)
				throw new MMSException("의사 정보가 없습니다.");			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		} finally{
			close(rset);
			close(pstmt);
		}		
		return list;
	}
	
	public ArrayList<Doctor> displayDept(Connection conn, String deptName) throws MMSException{ // 의사 부서로 조회
		ArrayList<Doctor> list = new ArrayList<Doctor>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		//String query = "select * from doctor where dept_no like ?"; //
		String query = "select * from doctor join department using(dept_no) where dept_name = ?";
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, deptName);
			
			rset = pstmt.executeQuery();
			
			while(rset.next()){
				Doctor d = new Doctor();
				d.setDocNo(rset.getString("doc_no"));
				d.setDocName(rset.getString("doc_name"));
				d.setDocRoom(rset.getInt("doc_room"));
				d.setDeptNo(rset.getString("dept_no"));
				d.setDeptName(rset.getString("dept_name"));
				
				list.add(d);
			}
			if(list.size()==0)
				throw new MMSException("의사 정보가 없습니다.");			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		} finally{
			close(rset);
			close(pstmt);
		}		
		return list;
	}
	
	public ArrayList<Doctor> displayDocNo(Connection conn, String docNo) throws MMSException{ // 의사 번호로 조회
		ArrayList<Doctor> list = new ArrayList<Doctor>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		//String query = "select * from doctor where dept_no like ?"; //
		String query = "select * from doctor join department using(dept_no) where doc_no = ?";
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, docNo);
			
			rset = pstmt.executeQuery();
			
			while(rset.next()){
				Doctor d = new Doctor();
				d.setDocNo(rset.getString("doc_no"));
				d.setDocName(rset.getString("doc_name"));
				d.setDocRoom(rset.getInt("doc_room"));
				d.setDeptNo(rset.getString("dept_no"));
				d.setDeptName(rset.getString("dept_name"));
				
				list.add(d);
			}
			if(list.size()==0)
				throw new MMSException("의사 정보가 없습니다.");			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		} finally{
			close(rset);
			close(pstmt);
		}		
		return list;
	}
	
	public ArrayList<Doctor> displayDeptAll(Connection conn) throws MMSException{
		ArrayList<Doctor> list = new ArrayList<Doctor>();
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "select dept_name from department";
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			while(rset.next()){
				Doctor d = new Doctor();
				d.setDeptName(rset.getString("dept_name"));
				
				list.add(d);
			}
			if(list.size() == 0)
				throw new MMSException("오류");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		}finally{
			close(rset);
			close(stmt);
		}
		return list;
	}
	
	
	public ArrayList<Doctor> displayDocAll(Connection conn, String deptName) throws MMSException{
		ArrayList<Doctor> list = new ArrayList<Doctor>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String query = "select doc_name from doctor join department using(dept_no) where dept_name = ?";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, deptName);			
			rset = pstmt.executeQuery();
			
			while(rset.next()){
				Doctor d = new Doctor();
				d.setDocName(rset.getString("doc_name"));
				
				list.add(d);
			}
			if(list.size() == 0)
				throw new MMSException("오류");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		}finally{
			close(rset);
			close(pstmt);
		}
		return list;
	}
	
	//진료실 조회
	public ArrayList<Doctor> displayRoom(Connection conn, String docRoom) throws MMSException{
		ArrayList<Doctor> list = new ArrayList<Doctor>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String query = "select * from doctor join department using (dept_no) where doc_room like ?";
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, "%" + docRoom + "%");
			
			rset = pstmt.executeQuery();
			
			while(rset.next()){
				Doctor d = new Doctor();
				d.setDocNo(rset.getString("doc_no"));
				d.setDocName(rset.getString("doc_name"));
				d.setDocRoom(rset.getInt("doc_room"));
				d.setDeptNo(rset.getString("dept_no"));
				d.setDeptName(rset.getString("dept_name"));
				
				list.add(d);
			}
			if(list == null)
				throw new MMSException("의사 정보가 없습니다.");
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		} finally{
			close(rset);
			close(pstmt);
		}		
		return list;
	}
	
	// 의사 이름으로 진료실 반환
	public int displayScheduleRoom(Connection conn, String docName) throws MMSException{
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		int docRoom = 0;
			
		String query = "select doc_room from doctor where doc_name = ?";
		
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, docName);
			
			rset = pstmt.executeQuery();
			
			if(rset.next()){
				docRoom = rset.getInt("doc_room");
			}
			
			if(docRoom == 0)
				throw new MMSException("정보가 없습니다.");
			
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		} finally{
			close(rset);
			close(pstmt);
		}		
		return docRoom;
	}
	
	public int displayInsert(Connection conn, Doctor d) throws MMSException{
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query = null;
		
		if(d.getDeptNo().equals("M01")){
			query = "insert into doctor "
					+ "values ('D' || LPAD(DOC_SEQ.NEXTVAL, 2, '0'), ?, DOC_R1_SEQ.NEXTVAL, ?)";	
		}
		else if(d.getDeptNo().equals("M02")){
			query = "insert into doctor "
					+ "values ('D' || LPAD(DOC_SEQ.NEXTVAL, 2, '0'), ?, DOC_R2_SEQ.NEXTVAL, ?)";	
		}
		else if(d.getDeptNo().equals("M03")){
			query = "insert into doctor "
					+ "values ('D' || LPAD(DOC_SEQ.NEXTVAL, 2, '0'), ?, DOC_R3_SEQ.NEXTVAL, ?)";	
		}
		else if(d.getDeptNo().equals("M04")){
			query = "insert into doctor "
					+ "values ('D' || LPAD(DOC_SEQ.NEXTVAL, 2, '0'), ?, DOC_R4_SEQ.NEXTVAL, ?)";	
		}
		else if(d.getDeptNo().equals("M05")){
			query = "insert into doctor "
					+ "values ('D' || LPAD(DOC_SEQ.NEXTVAL, 2, '0'), ?, DOC_R5_SEQ.NEXTVAL, ?)";	
		}
		else if(d.getDeptNo().equals("M06")){
			query = "insert into doctor "
					+ "values ('D' || LPAD(DOC_SEQ.NEXTVAL, 2, '0'), ?, DOC_R6_SEQ.NEXTVAL, ?)";	
		}
		else if(d.getDeptNo().equals("M07")){
			query = "insert into doctor "
					+ "values ('D' || LPAD(DOC_SEQ.NEXTVAL, 2, '0'), ?, DOC_R7_SEQ.NEXTVAL, ?)";	
		}
		else if(d.getDeptNo().equals("M08")){
			query = "insert into doctor "
					+ "values ('D' || LPAD(DOC_SEQ.NEXTVAL, 2, '0'), ?, DOC_R8_SEQ.NEXTVAL, ?)";	
		}
		else if(d.getDeptNo().equals("M09")){
			query = "insert into doctor "
					+ "values ('D' || LPAD(DOC_SEQ.NEXTVAL, 2, '0'), ?, DOC_R9_SEQ.NEXTVAL, ?)";	
		}
		else if(d.getDeptNo().equals("M10")){
			query = "insert into doctor "
					+ "values ('D' || LPAD(DOC_SEQ.NEXTVAL, 2, '0'), ?, DOC_R10_SEQ.NEXTVAL, ?)";	
		}		
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, d.getDocName());
			pstmt.setString(2, d.getDeptNo());
			
			result = pstmt.executeUpdate();
			
			if(result == 0)
				throw new MMSException("데이터 추가 실패");
			
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		} finally{
			close(pstmt);
		}		
		return result;
	}
	
	public int displayUpdate(Connection conn, Doctor d) throws MMSException{
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query = "update doctor set doc_name = ?, doc_room = ?, dept_no = ? where doc_no = ?";
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, d.getDocName());
			pstmt.setInt(2, d.getDocRoom());
			pstmt.setString(3, d.getDeptNo());
			pstmt.setString(4, d.getDocNo());
			
			result = pstmt.executeUpdate();
			
			if(result == 0)
				throw new MMSException("데이터 추가 실패");
			
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		} finally{
			close(pstmt);
		}	
		return result;
	}
	
	public int displayDelete(Connection conn, String docName) throws MMSException{
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query = "delete from doctor where doc_name = ? ";
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, docName);
			
			result = pstmt.executeUpdate();
			
			if(result == 0)
				throw new MMSException("데이터 삭제 실패");
			
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		} finally{
			close(pstmt);
		}	
		return result;
	}
}
