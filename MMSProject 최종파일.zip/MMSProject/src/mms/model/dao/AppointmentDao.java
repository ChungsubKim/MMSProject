package mms.model.dao;

import static mms.common.JDBCTemplate.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.JOptionPane;

import mms.exception.MMSException;
import mms.model.dto.Appointment;

public class AppointmentDao {
   public AppointmentDao(){}
   
   public ArrayList<Appointment> displayList(Connection conn) throws MMSException{ // 예약 전체 조회
      ArrayList<Appointment> list = new ArrayList<Appointment>();
      Statement stmt = null;
      ResultSet rset = null;
      
      String query = "select * from appointment";
      
      try{
         stmt = conn.createStatement();
         rset = stmt.executeQuery(query);
         
         while(rset.next()){
            Appointment a = new Appointment();
            a.setAppNo(rset.getString("app_no"));
            a.setAppDate(rset.getString("app_date"));
            a.setPatNo(rset.getString("pat_no"));
            a.setAppFirst(rset.getString("app_first"));
            a.setDocNo(rset.getString("doc_no"));
            a.setDeptNo(rset.getString("dept_no"));
            a.setAppMemo(rset.getString("app_memo"));
            
            list.add(a);
         }
         if(list.size() == 0)
            throw new MMSException("예약 정보가 없습니다.");         
      } catch(Exception e){
    	  JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
      } finally{
         close(rset);
         close(stmt);
      }      
      return list;
   }

   // 회원 번호로 회원 예약조회
   public ArrayList<Object[]> displayPatList(Connection conn, String patId) throws MMSException{
        ArrayList<Object[]> list = new ArrayList<Object[]>();
         PreparedStatement pstmt = null;
         ResultSet rset = null;
          
         // app_no, app_date, pat_name, doc_name, dept_name, app_memo, app_first 
         String query = "select app_no, to_char(app_date,'RR-MM-DD HH24:MI') as time, pat_name, doc_name, dept_name, app_memo, app_first "
               + "from appointment "
               + "join patient using(pat_no)"
               + "join department using(dept_no)"
               + "join doctor using(doc_no)"
               + "where pat_id like ? ";
         
         try {
            pstmt = conn.prepareStatement(query);
             pstmt.setString(1, patId);
             
             rset = pstmt.executeQuery();
           
             while(rset.next()){
                Object[] objArr = new Object[7];
                objArr[0] = rset.getString("app_no");
                //objArr[1] = rset.getDate("app_date");
                objArr[1] = rset.getString("time");
                objArr[2] = rset.getString("pat_name");
                objArr[3] = rset.getString("doc_name");
                objArr[4] = rset.getString("dept_name");
                objArr[5] = rset.getString("app_memo");
                objArr[6] = rset.getString("app_first");
                
                list.add(objArr);
            }
            if(list.size()==0)
               throw new MMSException("데이터 정보가 없습니다.");            
            } catch(Exception e){
               //throw new MMSException("회원 데이터 조회 실패");
            } finally{
               close(rset);
               close(pstmt);
          }
          return list;
    }
   
   // 진료과 이름으로 진료과번호 return
      public String displayDeptNo(Connection conn, String deptName) throws MMSException{
         String deptNo = null;
         
         PreparedStatement pstmt = null;
         ResultSet rset = null;
         
         String query = "select dept_no from department where dept_name = ?";
         
         try{
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, deptName);
            
            rset = pstmt.executeQuery();
            
            if(rset.next()){
               deptNo = rset.getString("dept_no");
            }
            if(deptNo.isEmpty())
               throw new MMSException("진료과 이름이 잘못되었습니다.");
            
         } catch(Exception e){
        	 JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
         } finally{
            close(rset);
            close(pstmt);
         }      
         return deptNo;
      }
      
      // 담당의 이름으로 담당의 번호 return
      public String displayDocNo(Connection conn, String docName) throws MMSException{
         String docNo = null;
         
         PreparedStatement pstmt = null;
         ResultSet rset = null;
         
         String query = "select doc_no from doctor where doc_name = ?";
         
         try{
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, docName);
            
            rset = pstmt.executeQuery();
            
            if(rset.next()){
               docNo = rset.getString("doc_no");
            }
            if(docNo.isEmpty())
               throw new MMSException("의사 이름이 잘못되었습니다.");
            
         } catch(Exception e){
        	 JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
         } finally{
            close(rset);
            close(pstmt);
         }      
         return docNo;   
      }
   
   // 부서 이름으로 Appointment 객체 return
      public ArrayList<Object[]> displayDept(Connection conn, String deptName, String docName) throws MMSException {
          ArrayList<Object[]> list = new ArrayList<Object[]>();
          PreparedStatement pstmt = null;
          ResultSet rset = null;
          
          String query = "Select a.APP_NO, p.pat_name, p.pat_ssn, "
        		  + "DECODE(SUBSTR(p.pat_ssn, 8, 1), '1', '남', '3', '남', '여') as gender, "
        		  + "TO_CHAR(APP_DATE,'RR-MM-DD HH24:MI') as APP_DATE, a.app_memo, a.app_first "
        		  + "FROM APPOINTMENT a "
        		  + "JOIN department e on (a.DEPT_NO = e.dept_no) "
        		  + "join patient p on (a.pat_no = p.pat_no) "
        		  + "JOIN doctor d on (a.DOC_NO = d.Doc_no) "
        		  + "where e.dept_name = ? and d.doc_name = ?";
          
          try {
             pstmt = conn.prepareStatement(query);
             pstmt.setString(1, deptName);
             pstmt.setString(2, docName);
             rset = pstmt.executeQuery();
             
             while(rset.next()) {
            	 Object[] objArr = new Object[7];
            	 //{"No.", "환자명", "주민등록번호", "성별", "날짜", "증상", "초진여부"};
            	 objArr[0] = rset.getString("app_no");
            	 objArr[1] = rset.getString("pat_name");
            	 objArr[2] = rset.getString("pat_ssn");
            	 objArr[3] = rset.getString("gender");
            	 objArr[4] = rset.getString("app_date");
            	 objArr[5] = rset.getString("app_memo");
            	 objArr[6] = rset.getString("app_first"); 
            	 
            	 int appYear = 2000+Integer.parseInt(rset.getString("app_date").substring(0,2)); // 예약 날짜
            	 int appMonth = Integer.parseInt(rset.getString("app_date").substring(3,5));
            	 int appDate = Integer.parseInt(rset.getString("app_date").substring(6,8));                               
                
            	 int curYear = Calendar.getInstance().get(Calendar.YEAR); // 현재 날짜
            	 int curMonth = Calendar.getInstance().get(Calendar.MONTH)+1;
            	 int curDate = Calendar.getInstance().get(Calendar.DATE);
               
            	 if( !((appYear == curYear) &&  (appMonth==curMonth) && (appDate==curDate)) ){
                	continue;
            	 }     
            	 list.add(objArr);
             }
             
             if(list.size() == 0)
                   throw new MMSException("해당 날짜의 예약이 없습니다.");    
          } catch (Exception e) {
        	  JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
          } finally {
             close(rset);
             close(pstmt);
          }
          return list;
       }
      
      
   
   public int displayInsert(Connection conn, Appointment a) throws MMSException{
         int result = 0;
         PreparedStatement pstmt = null;           
         
         /*String query = "insert into appointment "
               + "values ('A' || LPAD(APP_SEQ.NEXTVAL, 5, '0'), ?, ?, ?, ?, ?, ?)";*/
         
         String query = "insert into appointment "
               + "values ('A' || LPAD(APP_SEQ.NEXTVAL, 5, '0'), to_date(?, 'RR-MM-DD HH24:MI'), ?, ?, ?, ?, ?)";
         
         
         try {
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, a.getAppDate());
            pstmt.setString(2, a.getPatNo());
            pstmt.setString(3, a.getAppFirst());
            pstmt.setString(4, a.getDocNo());
            pstmt.setString(5, a.getDeptNo());
            pstmt.setString(6, a.getAppMemo());
            
            result = pstmt.executeUpdate();
            if(result == 0)
               throw new MMSException("데이터 추가 실패");
            
         } catch(Exception e){
        	 JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
         } finally{
            close(pstmt);
         }
         return result;
   }
      
   public int displayUpdate(Connection conn, Appointment a) throws MMSException{
      int result = 0;
      PreparedStatement pstmt = null;
      
      String query = "update appointment "
            + "app_date = ?, pat_no = ?, app_first = ?, "
            + "doc_no = ?, dept_no = ?, app_memo = ? where app_no = ?";
      try {
         pstmt = conn.prepareStatement(query);
         pstmt.setString(1, a.getAppDate());
         pstmt.setString(2, a.getPatNo());
         pstmt.setString(3, a.getAppFirst());
         pstmt.setString(4, a.getDocNo());
         pstmt.setString(5, a.getDeptNo());
         pstmt.setString(6, a.getAppMemo());
         pstmt.setString(7, a.getAppNo());
         result = pstmt.executeUpdate();
         if(result == 0)
            throw new MMSException("데이터 수정 실패");
         
      } catch(Exception e){
    	  JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
      } finally{
         close(pstmt);
      }
      return result;
   }
	
	public int displayDelete(Connection conn, String appNo) throws MMSException{
	      int result = 0;
	      PreparedStatement pstmt = null;
	      
	      String query = "delete from appointment where app_no = ?";
	      try {
	         pstmt = conn.prepareStatement(query);
	         pstmt.setString(1, appNo);
	            
	         result = pstmt.executeUpdate();
	         if(result == 0)
	            throw new MMSException("데이터 삭제 실패");
	         
	      } catch(Exception e){
	    	  JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
	      } finally{
	         close(pstmt);
	      }
	      return result;
	}
	

}
