package mms.run;

import javax.swing.JOptionPane;

import mms.view.LoginView;

public class Start {
	public static void main(String[] args) {
		new LoginView();
	}
}