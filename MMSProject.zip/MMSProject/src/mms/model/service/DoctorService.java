package mms.model.service;

import static mms.common.JDBCTemplate.close;
import static mms.common.JDBCTemplate.commit;
import static mms.common.JDBCTemplate.getConnection;
import static mms.common.JDBCTemplate.rollback;

import java.sql.Connection;
import java.util.ArrayList;

import mms.exception.MMSException;
import mms.model.dto.Doctor;

public class DoctorService extends AppointmentService{	
	
	public DoctorService(){}
	public ArrayList<Doctor> selectName(String docName) throws MMSException{
		Connection conn = getConnection();
		ArrayList<Doctor> list = dDao.displayName(conn, docName);
		close(conn);
		return list;
	}
	
	public int insertDoctor(Doctor d) throws MMSException{
		Connection conn = getConnection();
		int result = dDao.displayInsert(conn, d);
		if(result > 0)
			commit(conn);
		else
			rollback(conn);
		return result;
	}
	public int updateDoctor(Doctor d) throws MMSException{
		Connection conn = getConnection();
		int result = dDao.displayUpdate(conn, d);
		if(result > 0)
			commit(conn);
		else
			rollback(conn);
		return result;
	}
	public int deleteDoctor(Doctor d) throws MMSException{
		Connection conn = getConnection();
		int result = dDao.displayDelete(conn, d);
		if(result > 0)
			commit(conn);
		else
			rollback(conn);
		return result;
	}
	
}
