package mms.model.dao;

import static mms.common.JDBCTemplate.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import mms.exception.MMSException;
import mms.model.dto.Doctor;

public class DoctorDao extends AppointmentDao{
	
	public DoctorDao(){}
	public ArrayList<Doctor> displayName(Connection conn, String docName) throws MMSException{ // 의사 이름으로 조회
		ArrayList<Doctor> list = new ArrayList<Doctor>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String query = "select * from doctor join department using (dept_no) where doc_name like ?";
		
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, "%" + docName + "%");
			
			rset = pstmt.executeQuery();
			
			while(rset.next()){
				Doctor d = new Doctor();
				d.setDocNo(rset.getString("doc_no"));
				d.setDocName(rset.getString("doc_name"));
				d.setDocRoom(rset.getInt("doc_room"));
				d.setDeptNo(rset.getString("dept_no"));
				d.setDocName(rset.getString("dept_name"));
				
				list.add(d);
			}
			if(list.size()==0)
				throw new MMSException("의사 정보가 없습니다.");			
		} catch(Exception e) {
			throw new MMSException(e.getMessage());
		} finally{
			close(rset);
			close(pstmt);
		}		
		return list;
	}
	
	
	public int displayInsert(Connection conn, Doctor d) throws MMSException{
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query = "insert into doctor "
				+ "values (?, ?, ?, ?)";		
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, d.getDocNo());
			pstmt.setString(2, d.getDocName());
			pstmt.setInt(3, d.getDocRoom());
			pstmt.setString(4, d.getDeptNo());
			
			result = pstmt.executeUpdate();
			
			if(result == 0)
				throw new MMSException("데이터 추가 실패");
			
		} catch(Exception e){
			throw new MMSException(e.getMessage());
		} finally{
			close(pstmt);
		}		
		return result;
	}
	
	public int displayUpdate(Connection conn, Doctor d) throws MMSException{
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query = "update doctor set doc_name = ?, doc_room = ?, dept_no = ? where doc_no = ?";
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, d.getDocName());
			pstmt.setInt(2, d.getDocRoom());
			pstmt.setString(3, d.getDeptNo());
			pstmt.setString(4, d.getDocNo());
			
			result = pstmt.executeUpdate();
			
			if(result == 0)
				throw new MMSException("데이터 추가 실패");
			
		} catch(Exception e){
			throw new MMSException(e.getMessage());
		} finally{
			close(pstmt);
		}	
		return result;
	}
	
	public int displayDelete(Connection conn, Doctor d) throws MMSException{
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query = "delete from doctor where doc_no = ?";
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, d.getDocNo());
			
			result = pstmt.executeUpdate();
			
			if(result == 0)
				throw new MMSException("데이터 삭제 실패");
			
		} catch(Exception e){
			throw new MMSException(e.getMessage());
		} finally{
			close(pstmt);
		}	
		return result;
	}
}
