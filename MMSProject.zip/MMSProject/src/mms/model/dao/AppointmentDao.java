package mms.model.dao;

import static mms.common.JDBCTemplate.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import mms.exception.MMSException;
import mms.model.dto.Doctor;

public class AppointmentDao {
	
	public ArrayList<Doctor> displayList(Connection conn) throws MMSException { // 전체정보 출력
		ArrayList<Doctor> list = new ArrayList<Doctor>();
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "select * from doctor join department using (dept_no)";
		try{
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			while(rset.next()){
				Doctor d = new Doctor();
				d.setDocNo(rset.getString("doc_no"));
				d.setDocName(rset.getString("doc_name"));
				d.setDocRoom(rset.getInt("doc_room"));
				d.setDeptNo(rset.getString("dept_no"));
				d.setDeptName(rset.getString("dept_name"));
				
				list.add(d);
			}
			if(list.size()==0)
				throw new MMSException("의사 정보가 없습니다.");			
		} catch(Exception e){
			throw new MMSException(e.getMessage());
		} finally{
			close(rset);
			close(stmt);
		}		
		return list;
	}
	
	
	public ArrayList<Doctor> displayDept(Connection conn, String deptNo) throws MMSException{ // 의사 부서로 조회
		ArrayList<Doctor> list = new ArrayList<Doctor>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String query = "select * from doctor where dept_no like ?"; //
		//String query = "select *	from doctor join department using(dept_no) where dept_name = ?";
		try{
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, "%" + deptNo + "%");
			
			rset = pstmt.executeQuery();
			
			while(rset.next()){
				Doctor d = new Doctor();
				d.setDocNo(rset.getString("doc_no"));
				d.setDocName(rset.getString("doc_name"));
				d.setDocRoom(rset.getInt("doc_room"));
				d.setDeptNo(rset.getString("dept_no"));
				
				list.add(d);
			}
			if(list.size()==0)
				throw new MMSException("의사 정보가 없습니다.");			
		} catch(Exception e) {
			throw new MMSException(e.getMessage());
		} finally{
			close(rset);
			close(pstmt);
		}		
		return list;
	}

}
