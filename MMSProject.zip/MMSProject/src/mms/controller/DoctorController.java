package mms.controller;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import mms.model.dto.Doctor;

public class DoctorController extends AppointmentController{
	
	public DoctorController(){}
	
	public ArrayList<Doctor> selectName(String docName){
		ArrayList<Doctor> list = null;
		try{
			list = dService.selectName(docName);
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		}		
		return list;
	}
		
	public int insertDoctor(Doctor d){
		int result = 0;
		
		try{
			result = dService.insertDoctor(d);
			if(result > 0)
				System.out.println("상품이 등록되었습니다.");
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	public int UpdateDoctor(Doctor d){
		int result = 0;
		
		try{
			result = dService.updateDoctor(d);
			if(result > 0)
				System.out.println("상품이 수정되었습니다.");
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	public int DeleteDoctor(Doctor d){
		int result = 0;
		
		try{
			result = dService.deleteDoctor(d);
			if(result > 0)
				System.out.println("상품이 삭제되었습니다.");
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}

}
