package mms.controller;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import mms.model.dto.Doctor;
import mms.model.service.DoctorService;

public class AppointmentController {
	protected DoctorService dService = new DoctorService();


	public ArrayList<Doctor> selectList(){
		ArrayList<Doctor> list = null;
		
		try{
			list = dService.selectList();
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		}		
		return list;
	}

	public ArrayList<Doctor> selectDept(String deptNo){
		ArrayList<Doctor> list = null;
		try{
			list = dService.selectDept(deptNo);
		} catch(Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage(), "오류 발생", JOptionPane.ERROR_MESSAGE);
		}		
		return list;
	}
	
}
