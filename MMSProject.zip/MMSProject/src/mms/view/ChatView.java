package mms.view;

public class ChatView {

}
