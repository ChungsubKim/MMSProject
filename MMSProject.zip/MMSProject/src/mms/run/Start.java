package mms.run;

import mms.view.LoginView;

public class Start {
	public static void main(String[] args) {
		new LoginView().displayMenu();
	}
}