package mms.view;

public class PatientView {

}
