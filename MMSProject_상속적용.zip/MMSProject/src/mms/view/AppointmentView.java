package mms.view;

public class AppointmentView {

}
