package mms.view;

import java.util.ArrayList;
import java.util.Scanner;

import mms.controller.DoctorController;
import mms.controller.PatientController;
import mms.model.dto.Doctor;
import mms.model.dto.Patient;

public class LoginView{
	private Scanner sc = new Scanner(System.in);
	private DoctorController dController = new DoctorController();
	private PatientController pController = new PatientController();
	
	public LoginView(){}
	
	public void displayMenu(){
		int no;

		do {
			System.out.println("\n***** 테스트 *****\n");
			System.out.println("1. 의사 전체");
			System.out.println("2. 환자 전체");
			System.out.println("3. 의사 이름으로 조회");
			System.out.println("4. 부서번호로 조회"); // 부서이름으로 바꾸기
			System.out.println("5. 환자 번호로 조회");
			System.out.println("6. 환자 이름으로 조회");
			System.out.println("7. 환자 주민번호로 조회");
			System.out.println("8. 환자 전화번호로 조회");
			System.out.println("9. 프로그램 끝내기");
			System.out.print("번호 선택 : ");
			no = sc.nextInt();
			
			switch(no)
			{
			case 1:
				printDoctorList(dController.selectList());
				break;
			case 2:
				printPatientList(pController.selectList());
				break;
			case 3: 
				printDoctorList(dController.selectName(inputDocName()));
				break;
			case 4: 
				printDoctorList(dController.selectDept(inputDocDept()));
				break;
			case 5: 
				printPatientList(pController.selectNo(inputPatNo()));
				break;
			case 6:
				printPatientList(pController.selectName(inputPatName()));
				break;
			case 7:
				printPatientList(pController.selectSsn(inputPatSsn()));
				break;
			case 8:
				printPatientList(pController.selectPhone(inputPatPhone()));
				break;
			case 9: 
				System.out.print("\n정말로 끝내시겠습니까?(Y|N) : ");
				if (sc.next().toUpperCase().charAt(0) == 'Y')
				return;
			default:
				System.out.println("잘못된 번호가 선택되었습니다.");
		        System.out.println("다시 선택하십시오.");
		
			
			}
			
		} while(true);	
	}
	
	public void printDoctorList(ArrayList<Doctor> list){ // 의사 출력용 메소드
		if(list != null){
			for(Doctor d : list)
				System.out.println(d.toString());
		}
	}
	public void printPatientList(ArrayList<Patient> list){ // 의사 출력용 메소드
		if(list != null){
			for(Patient d : list)
				System.out.println(d.toString());
		}
	}
	
	public String inputDocName(){
		System.out.print("의사 이름 : ");
		return sc.next();
	}
	public String inputDocDept(){
		System.out.print("의사 부서 : ");
		return sc.next();
	}
	
	public String inputPatNo(){
		System.out.print("환자 번호 : ");
		return sc.next();
	}	
	public String inputPatName(){
		System.out.print("환자 이름 : ");
		return sc.next();
	}
	public String inputPatPhone(){
		System.out.print("환자 전화번호 : ");
		return sc.next();
	}
	public String inputPatSsn(){
		System.out.print("환자 주민번호(xxxxxx-xxxxxx) : ");
		return sc.next();
	}
	
	
	
	
	
	
	
}

/*public class LoginView extends JFrame {
	
	public LoginView(){		
		this.setTitle("");
		this.setBounds(100, 100, 350, 500);
		this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
		
		this.setResizable(false);
		this.setVisible(true);
		
	}

}*/
