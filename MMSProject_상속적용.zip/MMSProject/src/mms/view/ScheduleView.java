package mms.view;

public class ScheduleView {

}
