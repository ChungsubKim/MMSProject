package mms.model.service;

import static mms.common.JDBCTemplate.close;
import static mms.common.JDBCTemplate.getConnection;

import java.sql.Connection;
import java.util.ArrayList;

import mms.exception.MMSException;
import mms.model.dao.DoctorDao;
import mms.model.dto.Doctor;

public class AppointmentService {
	protected DoctorDao dDao = new DoctorDao();
	
	public ArrayList<Doctor> selectList() throws MMSException{
		Connection conn = getConnection();
		ArrayList<Doctor> list = dDao.displayList(conn);
		close(conn);
		return list;
	}
	
	public ArrayList<Doctor> selectDept(String deptNo) throws MMSException{
		Connection conn = getConnection();
		ArrayList<Doctor> list = dDao.displayDept(conn, deptNo);
		close(conn);
		return list;
	}
	

	
	
	
	

}
